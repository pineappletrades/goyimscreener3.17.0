"""Trend and EMA-zone rules. Each class is one switchable constraint in the app."""
from engine.plugin_api import Param, Rule


class MaStacked(Rule):
    id = "ma_stacked"
    name = "Fast MA above slow MA"
    group = "Trend"
    description = "The uptrend is intact: the fast moving average sits above the slow one."
    needs = ["ma_fast", "ma_slow"]

    def check(self, ctx, p):
        f, s = ctx.get("ma_fast"), ctx.get("ma_slow")
        return f > s, f"fast {f:.2f} vs slow {s:.2f}"


class SlowRising(Rule):
    id = "slow_rising"
    name = "Slow MA rising"
    group = "Trend"
    description = ("The slow moving average is higher than it was N days ago (a rising floor), by at least X%. "
                   "A flat slow line means the trend has stalled and the line is just a number, not support.")
    needs = ["ma_slow_series"]
    params = [Param("lookback", "Compare with N days ago", 20, unit="days", min=1, max=250, step=1),
              Param("min_pct", "Up at least", 0.0, unit="% over those days", min=-20, max=50, step=0.5)]

    def check(self, ctx, p):
        s = ctx.get("ma_slow_series")
        n = int(p["lookback"])
        if len(s) <= n:
            return True, "not enough history to check"
        now, then = s.iloc[-1], s.iloc[-1 - n]
        chg = (now / then - 1) * 100
        ctx.set("slow_slope", round(float(chg), 2))
        mn = float(p.get("min_pct") or 0)
        ok = chg > mn if mn == 0 else chg >= mn
        return ok, f"{chg:+.2f}% over {n} days" + ("" if ok else f" (needs {mn:+g}%)")


class PulledBack(Rule):
    id = "pulled_back"
    name = "Real pullback (was extended)"
    group = "Trend"
    description = "Price was at least X% above the fast MA recently, so this is a pullback, not a sideways chop."
    needs = ["dist_fast_series"]
    params = [
        Param("min_extension", "Was at least", 8.0, unit="% above fast MA", min=0, max=100, step=0.5),
        Param("lookback", "Within the last", 60, unit="days", min=5, max=250, step=1),
    ]

    def check(self, ctx, p):
        d = ctx.get("dist_fast_series").iloc[-int(p["lookback"]):]
        mx = d.max()
        return mx >= p["min_extension"], f"max {mx:+.1f}% above fast MA in {int(p['lookback'])}d"


class InZone(Rule):
    id = "in_zone"
    name = "Price in the buy zone"
    group = "Trend"
    description = "Today's low touched the fast MA (within X%) and the close held above the slow MA (minus Y%)."
    needs = ["low", "close", "ma_fast", "ma_slow", "ma_fast_series", "ma_slow_series", "bars"]
    params = [
        Param("above_fast", "Zone top: above fast MA", 2.0, unit="%", min=0, max=20, step=0.5),
        Param("below_slow", "Zone bottom: below slow MA", 2.0, unit="%", min=0, max=20, step=0.5),
        Param("approach", "'Approaching' if within", 6.0, unit="% above fast MA", min=0, max=30, step=0.5),
    ]

    def _flags(self, ctx, p):
        bars = ctx.get("bars")
        fast, slow = ctx.get("ma_fast_series"), ctx.get("ma_slow_series")
        return (bars["low"] <= fast * (1 + p["above_fast"] / 100)) & (bars["close"] >= slow * (1 - p["below_slow"] / 100))

    def check(self, ctx, p):
        flags = self._flags(ctx, p)
        ok = bool(flags.iloc[-1])
        ctx.set("entered_zone_today", bool(ok and not flags.iloc[-2]))
        low, fast, slow = ctx.get("low"), ctx.get("ma_fast"), ctx.get("ma_slow")
        level = "slow MA" if low < slow * (1 + p["below_slow"] / 100) else "fast MA"
        if ok:
            return True, f"touching the {level}"
        return False, f"low {(low / fast - 1) * 100:+.1f}% vs fast MA"

    def near(self, ctx, p):
        d = ctx.get("dist_fast_pct")
        return p["above_fast"] < d <= p["approach"]

    def chart(self, ctx, p, n):
        """Shade the zone and mark zone entries / reversal candles on the detail chart."""
        fast, slow = ctx.get("ma_fast_series").iloc[-n:], ctx.get("ma_slow_series").iloc[-n:]
        flags = self._flags(ctx, p).iloc[-n:]
        rev = ctx.get("reversal_series").iloc[-n:] if ctx.engine.field_available("reversal_series") else None
        entries = [i for i in range(1, len(flags)) if flags.iloc[i] and not flags.iloc[i - 1]]
        revs = [i for i in range(len(flags)) if flags.iloc[i] and rev is not None and rev.iloc[i]]
        return {
            "band": {"upper": [round(float(x), 4) for x in fast * (1 + p["above_fast"] / 100)],
                     "lower": [round(float(x), 4) for x in slow * (1 - p["below_slow"] / 100)],
                     "label": "Buy zone"},
            "markers": [{"i": i, "kind": "entry", "label": "Entered zone"} for i in entries]
                       + [{"i": i, "kind": "reversal", "label": "Reversal candle in zone"} for i in revs],
        }


class ReversalToday(Rule):
    id = "reversal_today"
    name = "Reversal candle today"
    group = "Trend"
    description = "Only alert when today's candle is green and closed in the top third of its range."
    needs = ["reversal_candle"]
    default_enabled = False

    def check(self, ctx, p):
        r = ctx.get("reversal_candle")
        return r, "reversal candle" if r else "no reversal candle"


class MarketRegime(Rule):
    id = "market_regime"
    name = "SPY above its slow MA"
    group = "Market"
    description = "Only take setups when the overall market (SPY) is above its slow moving average."
    needs = ["close", "ma_slow"]
    default_enabled = False

    def check(self, ctx, p):
        spy = ctx.other("SPY")
        c, s = spy.get("close"), spy.get("ma_slow")
        return c > s, f"SPY {c:.2f} vs {s:.2f}"


class MaTouch(Rule):
    """Investing-style alert: an uptrending stock pulls back and touches the fast or slow MA.

    Each line alerts separately: one alert the day price first touches the fast MA, another
    the day it first touches the slow MA. "Touch from" can also (or instead) alert when price
    has been BELOW the line and rallies up into it, to test the line as resistance.
    """
    id = "ma_touch"
    name = "Pullback touches the fast or slow MA"
    group = "Trend"
    description = ("Price has been trading above both averages, then today's low touched one of them "
                   "(each line alerts on its own). Switch 'Touch from' to also catch rallies into the line from below.")
    needs = ["bars", "ma_fast_series", "ma_slow_series", "dist_fast_pct"]
    default_enabled = False
    SIDES = ["From above (pullback to support)", "From below (rally into resistance)", "Both"]
    params = [
        Param("lines", "Alert on", "Both (separate alerts)", kind="choice",
              choices=["Both (separate alerts)", "Fast MA only", "Slow MA only"]),
        Param("side", "Touch from", "From above (pullback to support)", kind="choice", choices=SIDES),
        Param("tolerance", "Touch counts within", 0.5, unit="% of the line", min=0, max=5, step=0.1),
        Param("above_days", "On the same side of the line on", 15, unit="of the prior 20 days", min=0, max=20, step=1),
        Param("hold", "Close must stay on its side of the touched line", True, kind="bool"),
        Param("new_only", "Only the first day of a touch", True, kind="bool"),
        Param("approach", "'Approaching' if within", 3.0, unit="% of the line", min=0, max=20, step=0.5),
        Param("history", "Add how often the line held in the past (5 yrs)", True, kind="bool"),
    ]

    def _series(self, ctx, p):
        """{key: (touched, trend)}: keys fast/slow = support tests from above, fast_r/slow_r = resistance tests from below."""
        bars = ctx.get("bars")
        fast, slow = ctx.get("ma_fast_series"), ctx.get("ma_slow_series")
        tol = 1 + p["tolerance"] / 100
        side = p.get("side", self.SIDES[0])
        lines = {}
        if p["lines"] != "Slow MA only":
            lines["fast"] = fast
        if p["lines"] != "Fast MA only":
            lines["slow"] = slow
        above_both = (bars["close"] > fast) & (bars["close"] > slow)
        uptrend = above_both.shift(1).rolling(20).sum() >= p["above_days"]
        out = {}
        for k, line in lines.items():
            if side != self.SIDES[1]:
                t = bars["low"] <= line * tol
                if p["hold"]:
                    t &= bars["close"] >= line
                out[k] = (t, uptrend)
            if side != self.SIDES[0]:
                below = (bars["close"] < line).shift(1).rolling(20).sum() >= p["above_days"]
                t = bars["high"] >= line / tol
                if p["hold"]:
                    t &= bars["close"] <= line
                out[k + "_r"] = (t, below)
        return bars, fast, slow, out

    def check(self, ctx, p):
        bars, fast, slow, series = self._series(ctx, p)
        hits = []
        for k, (t, trend) in series.items():
            today = bool(t.iloc[-1]) and bool(trend.iloc[-1])
            if p["new_only"]:
                today = today and not bool(t.iloc[-2])
            ctx.set(f"touched_{k}", today)
            if today:
                hits.append(k)
        if not hits:
            low, high = bars["low"].iloc[-1], bars["high"].iloc[-1]
            side = p.get("side", self.SIDES[0])
            if side == self.SIDES[0] and not any(tr.iloc[-1] for _, tr in series.values()):
                days = int(((bars["close"] > fast) & (bars["close"] > slow)).iloc[-21:-1].sum())
                return False, f"above both lines on only {days} of the prior 20 days"
            if side == self.SIDES[1]:
                return False, f"high {(high / fast.iloc[-1] - 1) * 100:+.1f}% vs fast, {(high / slow.iloc[-1] - 1) * 100:+.1f}% vs slow"
            return False, f"low {(low / fast.iloc[-1] - 1) * 100:+.1f}% vs fast, {(low / slow.iloc[-1] - 1) * 100:+.1f}% vs slow"
        names = {"fast": "fast MA from above", "slow": "slow MA from above",
                 "fast_r": "fast MA from below (resistance)", "slow_r": "slow MA from below (resistance)"}
        if p.get("history", True):
            self._history(ctx, hits)
        if any(h.endswith("_r") for h in hits):
            ctx.set("resistance_test", True)
        return True, "touched the " + " and ".join(names[h] for h in hits)

    def _history(self, ctx, hits):
        """How often each touched line held in the past (support from above / resistance from below)."""
        from engine import backtest
        prof = ctx.profile
        kind = prof.get("ma_type", "EMA")
        lines = []
        for h in hits:
            length = int(prof.get("slow") if h.startswith("slow") else prof.get("fast"))
            try:
                hist = backtest.level_history(ctx.get("bars"), length, kind, side="below" if h.endswith("_r") else "above")
                if hist:
                    lines.append(backtest.level_line(hist))
            except Exception as e:
                ctx.engine.log(f"level history {ctx.ticker}: {e}")
        if lines:
            ctx.set("level_history", lines)

    def near(self, ctx, p):
        bars, fast, slow, series = self._series(ctx, p)
        c = float(bars["close"].iloc[-1])
        for k, (t, trend) in series.items():
            line = float((slow if k.startswith("slow") else fast).iloc[-1])
            if not trend.iloc[-1]:
                continue
            gap = (c / line - 1) * 100
            if (not k.endswith("_r") and 0 < gap <= p["approach"]) or (k.endswith("_r") and -p["approach"] <= gap < 0):
                return True
        return False

    def chart(self, ctx, p, n):
        bars, fast, slow, series = self._series(ctx, p)
        marks = []
        for k, (t, trend) in series.items():
            t = (t & trend).iloc[-n:]
            prev = t.shift(1, fill_value=False)
            res = k.endswith("_r")
            base = k[:-2] if res else k
            for i in range(len(t)):
                if t.iloc[i] and (not p["new_only"] or not prev.iloc[i]):
                    marks.append({"i": i, "kind": f"touch_{k}",
                                  "label": f"{'Tested' if res else 'Touched'} {base} MA {'from below' if res else ''}".strip()})
        return {"markers": marks, "legend": {"touch_fast": "Touched fast MA", "touch_slow": "Touched slow MA",
                                             "touch_fast_r": "Fast MA tested from below", "touch_slow_r": "Slow MA tested from below"}}
