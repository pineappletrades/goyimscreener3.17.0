"""Not overextended: skip stocks whose trend has already stretched far above the slow line."""
from engine.plugin_api import Param, Rule


class NotExtended(Rule):
    id = "not_extended"
    name = "Not overextended above the slow line"
    group = "Trend"
    description = ("Skips stocks that already ran too far: the fast line more than X% above the slow line, or the highest close "
                   "of the last N days more than Y% above the slow line. A touch after a huge run-up often means a bigger fall "
                   "back to the slow line. Set a limit to 0 to skip it.")
    needs = ["bars", "ma_fast_series", "ma_slow_series"]
    default_enabled = False
    params = [
        Param("max_spread", "Fast line at most", 10.0, unit="% above the slow line (0 = don't check)", min=0, max=200, step=1),
        Param("max_peak", "Highest close at most", 0.0, unit="% above the slow line (0 = don't check)", min=0, max=500, step=5),
        Param("days", "Look back for the highest close", 60, unit="trading days", min=5, max=252, step=5),
        Param("beta_adjust", "Scale by beta (high-beta stocks get less room)", False, kind="bool"),
    ]

    def check(self, ctx, p):
        import numpy as np
        bars = ctx.get("bars")
        F, S = ctx.get("ma_fast_series"), ctx.get("ma_slow_series")
        if bars is None or F is None or S is None or not len(S):
            return True, "not enough history to check"
        c = np.asarray(bars["close"].values, dtype="float64")
        Fv, Sv = np.asarray(F, dtype="float64")[-len(c):], np.asarray(S, dtype="float64")[-len(c):]
        n = min(len(c), len(Fv), len(Sv))
        c, Fv, Sv = c[-n:], Fv[-n:], Sv[-n:]
        from engine.strategy_bt import extension
        x = extension(c, Fv, Sv, n - 1, int(p["days"]))
        ctx.set("ext_spread", x["ext_spread"])
        ctx.set("ext_peak", x["ext_peak"])
        k, bt = 1.0, None
        if p.get("beta_adjust"):
            from engine import beta as beta_
            from engine.strategy_bt import beta_factor
            spy = ctx.other("SPY").get("bars")
            if spy is not None and len(spy):
                bt = beta_.from_prices(bars["close"].values, spy["close"].reindex(bars.index).values)
                if bt is not None:
                    ctx.set("beta", round(bt, 2))
            k = beta_factor(bt)
        tag = (f" × beta {bt:.2f}" + (f" (counted as {k:g})" if abs(k - bt) > 1e-9 else "")) if bt is not None else ""
        bad = []
        if p["max_spread"] and x["ext_spread"] is not None and x["ext_spread"] * k > p["max_spread"]:
            bad.append(f"fast line {x['ext_spread']:.1f}% above slow{tag} = {x['ext_spread'] * k:.1f} (max {p['max_spread']:g})")
        if p["max_peak"] and x["ext_peak"] is not None and x["ext_peak"] * k > p["max_peak"]:
            bad.append(f"ran {x['ext_peak']:.0f}% above slow in {int(p['days'])} days{tag} = {x['ext_peak'] * k:.0f} (max {p['max_peak']:g})")
        if bad:
            return False, "overextended: " + "; ".join(bad)
        return True, (f"fast {x['ext_spread']:+.1f}% vs slow" if x["ext_spread"] is not None else "ok") + \
            (f", peak {x['ext_peak']:+.0f}% above slow in {int(p['days'])}d" if x["ext_peak"] is not None else "")
