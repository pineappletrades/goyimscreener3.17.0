"""Macro + rotation filters: is this a market for swing longs, and is money leaving this stock's trade?"""
from engine.plugin_api import Param, Rule


class MacroRegime(Rule):
    id = "macro_regime"
    name = "Macro: market is OK for swings"
    group = "Macro"
    description = ("Score from -10 to +10 built from VIX (level and spikes), SPY's trend and drawdown, breadth (RSP vs SPY) "
                   "and credit (HYG vs IEF). Blocks alerts when the market is risk-off.")
    needs = ["bars"]
    default_enabled = False
    params = [Param("min_score", "Macro score at least", -2.0, unit="(-10 to +10; -2 = not risk-off, +3 = risk-on)",
                    min=-10, max=10, step=0.5)]

    def check(self, ctx, p):
        from engine import macro
        snap = macro.snapshot(ctx.engine)
        ctx.set("macro_score", snap["score"])
        if snap["score"] is None:
            return True, "not checked: not enough macro data"
        return snap["score"] >= p["min_score"], f"{snap['regime']} {snap['score']:+.1f} · VIX {snap['vix']} ({snap['fear']})"


class ThemeHealth(Rule):
    id = "theme_health"
    name = "Rotation: money isn't leaving this stock's theme"
    group = "Macro"
    description = ("Matches the stock to the ETF it actually trades with (e.g. WDC → SMH, the AI/semis trade). Blocks it when "
                   "that theme is losing strength vs SPY, lagged SPY by 2%+ in 10 days, or is overvalued — any 2 of the 3.")
    needs = ["bars"]
    default_enabled = False
    params = [Param("max_risk", "Block when this many warnings", 2, unit="of 3 (weakening, outflow, overvalued)", min=1, max=3, step=1)]

    def check(self, ctx, p):
        from engine import macro
        etf, corr = macro.stock_theme(ctx.engine, ctx.ticker, ctx.get("bars"))
        if etf is None:
            return True, "not checked: no theme match"
        t = macro.snapshot(ctx.engine)["themes"].get(etf)
        if t is None:
            return True, f"not checked: no data for {etf}"
        ctx.set("theme", {"etf": etf, "corr": corr, **t})
        bad = t["risk"] >= int(p["max_risk"])
        warn = f" — warnings: {', '.join(t['flags'])}" if t["flags"] else ""
        return not bad, f"trades with {etf} (corr {corr}): {t['text']}{warn}"


class NoRepeatFailure(Rule):
    id = "no_repeat_failure"
    name = "Skip repeat signals after the line just failed"
    group = "Support"
    description = ("If the stock touched this same line in the last N days and then closed more than 2% below it, "
                   "don't alert again: the support already broke once (the WDC problem: repeat signals while it kept falling).")
    needs = ["bars", "ma_fast_series", "ma_slow_series"]
    default_enabled = False
    params = [Param("days", "Look back", 30, unit="trading days", min=5, max=120, step=1)]

    def check(self, ctx, p):
        from engine import backtest
        prof = ctx.profile
        bars = ctx.get("bars")
        kind = prof.get("ma_type", "EMA")
        lookback = int(p["days"])
        fails = []
        for length in (int(prof.get("fast", 150)), int(prof.get("slow", 200))):
            r = backtest.run(bars.iloc[:-1], fast=length, slow=length, kind=kind, side="above", hold=False,
                             above_days=10, held_days=10)
            n = len(bars) - 1
            c = bars["close"].values
            line = (bars["close"].rolling(length).mean() if kind == "SMA" else bars["close"].ewm(span=length, adjust=False).mean()).values
            for e in r["events"]:
                if e["line"] != "fast" or n - e["i"] > lookback:
                    continue
                if any(c[x] < line[x] * 0.98 for x in range(e["i"] + 1, n)):      # broke since, up to yesterday
                    fails.append(f"{kind} {length} failed after the {e['date']} touch")
        if fails:
            return False, fails[-1]
        return True, f"no failed touches in the last {lookback} days"
