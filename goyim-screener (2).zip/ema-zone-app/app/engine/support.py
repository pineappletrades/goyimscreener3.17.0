"""Is anyone actually defending this EMA?  Support signals for a pullback that touches the line.

The problem: some pullbacks slice straight through the 150/200 EMA, others bounce off it to the cent.
These signals try to tell them apart. Two kinds:

HISTORY signals (daily price + volume only, so they can be backtested over 5 years):
  light_pullback  volume over the 5 days into the touch was below its 50-day average
                  -> a calm pullback, sellers aren't in a hurry
  strong_close    the touch day closed in the top half of its range
                  -> buyers stepped in at the line before the close
  absorption      touch-day volume >= 1.3x average AND it still closed in the top half
                  -> heavy selling met heavier buying (someone big defended the level)
  accumulation    the accumulation/distribution line rose over the last 20 days
                  -> more volume on up-closes than down-closes while price pulled back
  respected       the same line held on at least 60% of its earlier tests (2+ tests)

LIVE signals (only exist today, so they're tracked forward instead of backtested):
  gamma_support   put wall / big positive gamma within 1.5% of the line, above the gamma flip
  bullish_flow    estimated option premium leans bullish (calls bought / puts sold)
  bid_support     bid/ask sizes sampled during the day: bids outweigh asks and keep building near the line
"""
import math

import numpy as np

HIST = [
    ("light_pullback", "Pullback on light volume",
     "Volume over the 5 days into the touch was below its 50-day average: sellers weren't in a hurry."),
    ("strong_close", "Closed strong at the line",
     "The touch day closed in the top half of its range: buyers stepped in at the line."),
    ("absorption", "Heavy volume, but it held",
     "Touch-day volume at least 1.3× average and it still closed in the top half: big buyers absorbed the selling."),
    ("accumulation", "Accumulation into the pullback",
     "The accumulation/distribution line rose over the last 20 days: more volume on up-closes than down-closes."),
    ("respected", "Line held before",
     "This line held on at least 60% of its earlier tests (2 or more tests)."),
]
LIVE = [
    ("gamma_support", "Gamma support at the line",
     "A put wall or a big positive-gamma cluster within 1.5% of the line, with price above the gamma flip."),
    ("bullish_flow", "Bullish option flow",
     "Today's estimated option premium leans bullish (calls bought, puts sold)."),
    ("bid_support", "Bids building near the line",
     "Bid/ask sizes sampled during the day: bids outweighed asks and grew while price was near the line."),
]
ALL = HIST + LIVE
LABEL = {k: lab for k, lab, _ in ALL}
DEFAULTS = {"light_ratio": 0.9, "strong_clv": 0.5, "absorb_mult": 1.3, "accum_days": 20,
            "respect_rate": 60.0, "respect_tests": 2, "held_pct": 2.0, "held_days": 10,
            "gamma_dist": 1.5, "bid_ratio": 0.55, "bid_samples": 5}


def _p(p):
    return dict(DEFAULTS, **{k: v for k, v in (p or {}).items() if v is not None})


# ----------------------------------------------------------------------
# history signals, vectorised: arrays are (days x tickers); a 1-D series works too
# ----------------------------------------------------------------------
def _2d(a):
    a = np.asarray(a, dtype="float64")
    return a.reshape(-1, 1) if a.ndim == 1 else a


def hist_masks(h, l, c, v, p=None):
    """{signal: bool array} where row i says whether the signal is on for a touch ON day i.
    Uses only day i and earlier."""
    import pandas as pd

    p = _p(p)
    h, l, c, v = _2d(h), _2d(l), _2d(c), _2d(v)
    rng = h - l
    with np.errstate(invalid="ignore", divide="ignore"):
        clv = np.where(rng > 0, (c - l) / rng, 0.5)                       # 0 = closed on the low, 1 = on the high
        V = pd.DataFrame(v)
        avg50 = V.shift(1).rolling(50, min_periods=30).mean().values       # prior 50 days, not including today
        prior5 = V.shift(1).rolling(5, min_periods=5).mean().values
        light = prior5 <= p["light_ratio"] * avg50
        strong = clv >= p["strong_clv"]
        absorb = (v >= p["absorb_mult"] * avg50) & strong
        mfm = np.where(rng > 0, ((c - l) - (h - c)) / rng, 0.0)            # money-flow multiplier
        ad = np.cumsum(np.nan_to_num(mfm * v), axis=0)
        n = int(p["accum_days"])
        ad_prev = np.vstack([np.full((n, ad.shape[1]), np.nan), ad[:-n]]) if len(ad) > n else np.full_like(ad, np.nan)
        accum = (ad - ad_prev) > 0
    nan_any = np.isnan(c) | np.isnan(v)
    out = {}
    for k, m in (("light_pullback", light), ("strong_close", strong), ("absorption", absorb), ("accumulation", accum)):
        out[k] = np.where(nan_any, False, np.nan_to_num(m, nan=0).astype(bool))
    out["clv"] = clv
    with np.errstate(invalid="ignore", divide="ignore"):
        out["vol_ratio"] = v / avg50
    return out


def _held(c, line, i, side, p):
    """Did the line hold after a touch on day i? None if not enough days yet."""
    hd = int(p["held_days"])
    if i + hd >= len(c):
        return None
    seg_c, seg_l = c[i + 1:i + 1 + hd], line[i + 1:i + 1 + hd]
    if side == "below":
        return not bool(np.any(seg_c > seg_l * (1 + p["held_pct"] / 100)))
    return not bool(np.any(seg_c < seg_l * (1 - p["held_pct"] / 100)))


def respected_masks(touch, line, c, p=None, side="above", cooldown=10):
    """For every day: hold rate of this line's EARLIER tests that had finished by then (no look-ahead).
    Returns (bool mask, rate %, tests) arrays (days x tickers)."""
    p = _p(p)
    touch, line, c = np.asarray(touch, bool), _2d(line), _2d(c)
    if touch.ndim == 1:
        touch = touch.reshape(-1, 1)
    n, m = c.shape
    rate = np.full((n, m), np.nan)
    tests = np.zeros((n, m), dtype="int32")
    hd = int(p["held_days"])
    for j in range(m):
        idx = np.nonzero(touch[:, j])[0]
        events, last = [], -10 ** 9
        for i in idx:
            if i - last > cooldown:
                events.append(i)
            last = i
        done = []                                   # (day the result is known, held)
        for i in events:
            hld = _held(c[:, j], line[:, j], i, side, p)
            if hld is not None:
                done.append((i + hd + 1, hld))
        if not done:
            continue
        done.sort()
        known_days = np.array([d for d, _ in done])
        cum_held = np.cumsum([1 if h_ else 0 for _, h_ in done])
        k = np.searchsorted(known_days, np.arange(n), side="right")     # how many results are known by day i
        has = k > 0
        tests[:, j] = k
        rate[has, j] = 100.0 * cum_held[k[has] - 1] / k[has]
    mask = (tests >= int(p["respect_tests"])) & (np.nan_to_num(rate, nan=0) >= p["respect_rate"])
    return mask, rate, tests


# ----------------------------------------------------------------------
# live signals
# ----------------------------------------------------------------------
def gamma_signal(g, line_name, p=None):
    """(ok, detail) from a get_gamma() result that included this EMA in its confirmations."""
    p = _p(p)
    if not g or not g.get("ok"):
        return None, "no option data"
    conf = next((x for x in g.get("confirmations") or [] if x["name"] == line_name), None)
    spot = g.get("spot")
    above_flip = g.get("flip") is None or (spot or 0) >= g["flip"]
    if conf is None:
        return None, f"{line_name} not in the gamma map"
    ok = conf["score"] >= 2 and above_flip
    return ok, f"{conf['label']} ({'; '.join(conf['why'])})"


def flow_signal(g):
    if not g or not g.get("ok") or not g.get("flow"):
        return None, "no option data"
    f = g["flow"]
    net = f.get("net_premium")
    if net is None:
        return None, "no flow"
    money = f"${abs(net) / 1e6:,.1f}M" if abs(net) >= 1e6 else f"${abs(net) / 1e3:,.0f}K"
    return net > 0, f"net premium {'+' if net > 0 else '−'}{money} ({'bullish' if net > 0 else 'bearish'} lean)"


def book_signal(metrics, p=None):
    """(ok, detail) from book.day_metrics()."""
    p = _p(p)
    if not metrics or metrics.get("samples", 0) < int(p["bid_samples"]):
        n = (metrics or {}).get("samples", 0)
        return None, f"only {n} bid/ask samples today (needs {int(p['bid_samples'])} while the market is open)"
    ratio, growth = metrics["bid_share"], metrics.get("bid_growth")
    ok = ratio >= p["bid_ratio"] and (growth is None or growth >= 0)
    g_txt = "n/a" if growth is None else f"{growth:+.0f}%"
    held = metrics.get("bid_held")
    txt = f"bids {ratio * 100:.0f}% of top-of-book size, bid size {g_txt} through the day ({metrics['samples']} samples)"
    if held is not None:
        txt += ", bid held at the line" if held else ", bid dropped below the line"
        ok = ok and held
    return ok, txt


# ----------------------------------------------------------------------
# one stock, today (scan + alerts)
# ----------------------------------------------------------------------
def check_today(bars, line_len, kind="EMA", side="above", p=None, gamma=None, book_metrics=None,
                want=None):
    """Every signal for a touch today on the `line_len` average. Returns
    {"line": "EMA 200", "level": float, "signals": {id: {"ok": True/False/None, "detail": str}}, "score": "4/6"}."""
    from . import backtest

    p = _p(p)
    want = set(want or [k for k, _, _ in ALL])
    c = bars["close"]
    line = c.rolling(line_len).mean() if kind == "SMA" else c.ewm(span=line_len, adjust=False).mean()
    hm = hist_masks(bars["high"].values, bars["low"].values, c.values, bars["volume"].values, p)
    sig = {}

    def put(k, ok, detail):
        if k in want:
            sig[k] = {"ok": None if ok is None else bool(ok), "detail": detail}

    vr, clv = hm["vol_ratio"][-1, 0], hm["clv"][-1, 0]
    v5 = float(bars["volume"].iloc[-6:-1].mean() / bars["volume"].iloc[-51:-1].mean()) if len(bars) > 51 else None
    put("light_pullback", hm["light_pullback"][-1, 0], f"5-day volume {v5:.2f}× average" if v5 else "not enough history")
    put("strong_close", hm["strong_close"][-1, 0], f"closed {clv * 100:.0f}% of the way up today's range")
    put("absorption", hm["absorption"][-1, 0],
        f"volume {vr:.1f}× average, closed {clv * 100:.0f}% up the range" if not math.isnan(vr) else "not enough history")
    put("accumulation", hm["accumulation"][-1, 0], f"A/D line {'rising' if hm['accumulation'][-1, 0] else 'falling'} over {int(p['accum_days'])} days")
    if "respected" in want:
        try:
            hist = backtest.level_history(bars.iloc[:-1], line_len, kind, side=side, held_pct=p["held_pct"], held_days=int(p["held_days"]))
        except Exception:
            hist = None
        if hist and hist["tests"]:
            ok = hist["tests"] >= int(p["respect_tests"]) and hist["rate"] >= p["respect_rate"]
            put("respected", ok, f"held {hist['held']} of {hist['tests']} earlier tests ({hist['rate']:.0f}%)")
        else:
            put("respected", None if hist is None else False, "no earlier tests" if hist else "not enough history")
    name = f"{kind} {line_len}"
    if gamma is not None:
        put("gamma_support", *gamma_signal(gamma, name, p))
        put("bullish_flow", *flow_signal(gamma))
    else:
        put("gamma_support", None, "option data not loaded")
        put("bullish_flow", None, "option data not loaded")
    put("bid_support", *book_signal(book_metrics, p))
    known = [x for x in sig.values() if x["ok"] is not None]
    return {"line": name, "level": float(line.iloc[-1]), "signals": sig,
            "passed": sum(1 for x in known if x["ok"]), "checked": len(known),
            "score": f"{sum(1 for x in known if x['ok'])}/{len(known)}"}


def summary_line(chk, only=None):
    """'🛡 Support check 4/6 at EMA 200: ✓ light-volume pullback · ✗ absorption · …' for Telegram."""
    if not chk:
        return ""
    bits = []
    for k, lab, _ in ALL:
        x = chk["signals"].get(k)
        if x is None or (only and k not in only):
            continue
        mark = "✓" if x["ok"] else "✗" if x["ok"] is False else "–"
        bits.append(f"{mark} {lab.lower()}")
    return f"🛡 Support check {chk['score']} at {chk['line']}: " + " · ".join(bits)


# ----------------------------------------------------------------------
# which signals predicted a hold (Backtest / Strategy Test tables)
# ----------------------------------------------------------------------
def compare(rows, keys=None):
    """rows: [{"signals": {id: bool}, "held": bool|None, "ret": float|None, "r252": float|None}]
    -> [{"id", "label", "with": {...}, "without": {...}, "edge": held-rate difference}]"""
    keys = keys or [k for k, _, _ in HIST]

    def stats(rs):
        held = [r["held"] for r in rs if r.get("held") is not None]
        rets = [r["ret"] for r in rs if r.get("ret") is not None]
        y1 = [r["r252"] for r in rs if r.get("r252") is not None]
        return {"n": len(rs), "held_rate": round(100 * sum(held) / len(held), 1) if held else None,
                "held_n": len(held), "avg": round(float(np.mean(rets)), 2) if rets else None,
                "win": round(100 * float(np.mean([x > 0 for x in rets])), 1) if rets else None,
                "y1_avg": round(float(np.mean(y1)), 2) if y1 else None}
    out = []
    for k in keys:
        on = [r for r in rows if (r.get("signals") or {}).get(k)]
        off = [r for r in rows if (r.get("signals") or {}).get(k) is False]
        w, wo = stats(on), stats(off)
        edge = (w["held_rate"] - wo["held_rate"]) if w["held_rate"] is not None and wo["held_rate"] is not None else None
        out.append({"id": k, "label": LABEL[k], "with": w, "without": wo, "edge": None if edge is None else round(edge, 1)})
    return out


def recent_fail_masks(touch, line, c, lookback=30, cooldown=10, fail_pct=2.0):
    """Day i is True when this line was touched within the last `lookback` days and price has since closed
    more than `fail_pct`% below it (the support already broke once). Past data only."""
    touch, line, c = np.asarray(touch, bool), _2d(line), _2d(c)
    if touch.ndim == 1:
        touch = touch.reshape(-1, 1)
    n, m = c.shape
    out = np.zeros((n, m), dtype=bool)
    with np.errstate(invalid="ignore"):
        below = c < line * (1 - fail_pct / 100)
    for j in range(m):
        idx = np.nonzero(touch[:, j])[0]
        last = -10 ** 9
        for e in idx:
            if e - last <= cooldown:
                last = e
                continue
            last = e
            br = np.nonzero(below[e + 1:min(n, e + 1 + lookback), j])[0]
            if len(br):
                f = e + 1 + br[0]                      # day it broke
                out[f + 1:min(n, e + lookback + 1), j] = True     # block later touches inside the window
    return out
