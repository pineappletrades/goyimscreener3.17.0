"""Entry-quality measures for a touch of the 150/200 line, shared by the Strategy Test and the daily scan.

  pullback speed   how hard it fell into the line: drop from the highest close of the last N days, and the
                   biggest gap down in those days. Slow drifts are profit-taking; fast drops / gaps are usually news.
  relative weakness  the stock's last N days vs SPY's (and its sector ETF's). Falling with the market recovers;
                   falling alone means something is wrong with the company.
  touch number     which touch of this line it is in the last year (1 = first pullback after the run).
                   Later touches = an older trend with fewer buyers left.
  slow-line slope  % change of the slow line over N days. Flat = the trend has stalled and the line is just a number.

Every function takes plain numpy arrays (oldest first) and a day index, so no future data is ever used.
"""
import numpy as np

TOUCH_GAP = 10        # a new touch "episode" needs this many trading days without touching
TOUCH_WINDOW = 252    # count touches over the last year


def pullback(c, o, i, days=5):
    """(drop %, biggest gap down %) over the last `days` days, both <= 0. Drop = close vs the highest prior close."""
    k0 = max(0, i - days)
    prev = c[k0:i]
    prev = prev[np.isfinite(prev)]
    drop = (c[i] / prev.max() - 1) * 100 if len(prev) and np.isfinite(c[i]) and prev.max() > 0 else None
    gap = None
    if i >= 1:
        with np.errstate(divide="ignore", invalid="ignore"):
            g = o[k0 + 1:i + 1] / c[k0:i] - 1
        g = g[np.isfinite(g)]
        gap = float(min(0.0, g.min()) * 100) if len(g) else None
    return (None if drop is None else float(min(0.0, drop))), gap


def ret(x, i, days):
    if i - days < 0:
        return None
    a, b = x[i - days], x[i]
    return float((b / a - 1) * 100) if np.isfinite(a) and np.isfinite(b) and a > 0 else None


def relative(c, m, i, days=20):
    """Stock's return minus the benchmark's over the last `days` days (percentage points). Negative = weaker."""
    r1, r2 = ret(c, i, days), ret(m, i, days) if m is not None else None
    return None if r1 is None or r2 is None else r1 - r2


def slope(S, i, days=60):
    return ret(S, i, days)


def episode_starts(touch):
    """touch: bool array (days x tickers, or days). True where a new touch episode starts
    (touching today and not in the previous TOUCH_GAP days)."""
    t = np.asarray(touch, dtype=bool)
    cs = np.cumsum(t, axis=0)
    prev = np.zeros_like(cs)
    prev[TOUCH_GAP + 1:] = cs[TOUCH_GAP:-1] - cs[:-TOUCH_GAP - 1] if len(cs) > TOUCH_GAP + 1 else 0
    prev[1:TOUCH_GAP + 1] = cs[:TOUCH_GAP] if len(cs) > 1 else 0
    return t & (prev == 0)


def touch_counts(starts):
    """Number of touch episodes in the last TOUCH_WINDOW days, counting today (same shape as starts)."""
    cs = np.cumsum(np.asarray(starts, dtype=int), axis=0)
    out = cs.copy()
    out[TOUCH_WINDOW:] = cs[TOUCH_WINDOW:] - cs[:-TOUCH_WINDOW]
    return out


def touch_number(low, line, tol_pct=0.5, i=None):
    """Touch number of day i (default: last day) for one stock's low/line arrays."""
    low, line = np.asarray(low, dtype="float64"), np.asarray(line, dtype="float64")
    with np.errstate(invalid="ignore"):
        t = low <= line * (1 + tol_pct / 100)
    i = len(low) - 1 if i is None else i
    return int(touch_counts(episode_starts(t))[i])


# ---- the filters (alert dict + Strategy Test params -> skip?) ----
def too_fast(a, p):
    md, mg = float(p.get("speed_max_drop") or 0), float(p.get("speed_max_gap") or 0)
    if md and a.get("pb_drop") is not None and -a["pb_drop"] > md:
        return True
    if mg and a.get("pb_gap") is not None and -a["pb_gap"] > mg:
        return True
    return False


def too_weak(a, p):
    ms, mx = float(p.get("rel_max_spy") or 0), float(p.get("rel_max_sec") or 0)
    if ms and a.get("rel_spy") is not None and -a["rel_spy"] > ms:
        return True
    if mx and a.get("rel_sec") is not None and -a["rel_sec"] > mx:
        return True
    return False


def too_many_touches(a, p):
    mx = int(p.get("touch_max") or 0)
    return bool(mx and a.get("touch_n") is not None and a["touch_n"] > mx)


def too_flat(a, p):
    mn = p.get("slope_min")
    if mn in (None, ""):
        return False
    return a.get("slow_slope") is not None and a["slow_slope"] < float(mn)
