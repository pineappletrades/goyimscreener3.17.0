"""Beta vs SPY: how much a stock (or a whole strategy) tends to move when the market moves.

beta = covariance(daily returns, SPY daily returns) / variance(SPY daily returns), over the last year.
1.0 = moves with the market; 1.5 = about 1.5x SPY's moves (both ways); 0.5 = half; below 0 = tends to move opposite.
"""
import numpy as np

WINDOW = 252          # one trading year
MIN_DAYS = 120

BUCKETS = [("Below 0.8 (defensive)", None, 0.8), ("0.8–1.2 (market-like)", 0.8, 1.2), ("1.2–1.6 (aggressive)", 1.2, 1.6),
           ("1.6–2.0 (high beta)", 1.6, 2.0), ("2.0 or more (very high)", 2.0, None)]


def from_prices(stock, market, window=WINDOW, min_days=MIN_DAYS):
    """Beta of the last `window` daily returns. stock/market: aligned close arrays (oldest first)."""
    s = np.asarray(stock, dtype="float64")[-(window + 1):]
    m = np.asarray(market, dtype="float64")[-(window + 1):]
    n = min(len(s), len(m))
    if n < min_days + 1:
        return None
    s, m = s[-n:], m[-n:]
    rs, rm = s[1:] / s[:-1] - 1, m[1:] / m[:-1] - 1
    ok = np.isfinite(rs) & np.isfinite(rm)
    if ok.sum() < min_days:
        return None
    rs, rm = rs[ok], rm[ok]
    var = rm.var()
    if var <= 0:
        return None
    return float(np.cov(rs, rm, ddof=0)[0, 1] / var)


def from_returns(rs, rm):
    """Beta, correlation and yearly alpha (%) of a return series vs the market's, on the same days."""
    rs, rm = np.asarray(rs, dtype="float64"), np.asarray(rm, dtype="float64")
    ok = np.isfinite(rs) & np.isfinite(rm)
    rs, rm = rs[ok], rm[ok]
    if len(rs) < 20 or rm.var() <= 0:
        return None
    b = float(np.cov(rs, rm, ddof=0)[0, 1] / rm.var())
    corr = float(np.corrcoef(rs, rm)[0, 1]) if rs.std() > 0 else None
    alpha = float((rs.mean() - b * rm.mean()) * 252 * 100)
    return {"beta": round(b, 2), "corr": None if corr is None else round(corr, 2), "alpha": round(alpha, 1)}


def bucket(b):
    if b is None:
        return None
    for name, lo, hi in BUCKETS:
        if (lo is None or b >= lo) and (hi is None or b < hi):
            return name
    return None


def describe(b):
    if b is None:
        return "n/a"
    if b < 0:
        return "moves against the market"
    if b < 0.8:
        return "defensive"
    if b < 1.2:
        return "moves with the market"
    if b < 1.6:
        return "aggressive"
    return "high beta"
