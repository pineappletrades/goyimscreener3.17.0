"""Strategy backtest: replay the Investing alert every day for ~5 years, then test stop losses.

1. Data (cached): 5 years of daily bars from Public for every stock in the universe + SPY, QQQ, RSP,
   and point-in-time fundamentals from SEC (each quarter only counts from the day after it was filed).
2. Signals: the same rules as the live Investing strategy (MA touch in an uptrend, market cap, FCF,
   revenue growth, EPS growth), evaluated with only the information available on each day.
3. Trades: buy each alert at that day's close, hold up to `hold` trading days (252 = 1 year),
   with or without a stop loss. Every trade is compared with SPY, QQQ and RSP (equal-weight S&P 500)
   over exactly the same days.
4. Stop-loss finder: the same alerts replayed with many stop rules, ranked.
5. Portfolio: equal-sized slots (default 10), $10,000 start, compared with buying and holding each benchmark.

Known limits (shown in the app): the stock list is today's companies (firms that went bust or were
bought out are missing = survivorship bias); fills are at the close / stop price with no fees or slippage.
"""
import functools
import math
import os
import pickle
import time
from datetime import date, datetime, timedelta

import numpy as np

from . import paths, store

BENCHES = [("SPY", "S&P 500"), ("QQQ", "Nasdaq 100"), ("RSP", "S&P 500 equal weight")]
HORIZONS = [5, 21, 63, 126, 252]
DATASET_FILE = "strategy_bt_dataset.pkl"
RESULT_FILE = "strategy_bt_result.json"
ALERTS_FILE = "strategy_bt_alerts.json"      # every alert day of the last run (the result keeps only the newest 400)

STOP_GRID = (
    [{"type": "none", "label": "No stop"}]
    + [{"type": "pct", "value": v, "label": f"{v}% below entry"} for v in (3, 5, 7, 10, 12, 15, 20, 25, 30)]
    + [{"type": "atr", "value": v, "label": f"{v}× ATR below entry"} for v in (1.5, 2, 3, 4)]
    + [{"type": "line", "value": v, "label": f"Close {v}% under the touched EMA"} for v in (0, 1, 2, 3, 5, 8)]
    + [{"type": "slow", "value": v, "label": f"Close {v}% under the slow EMA"} for v in (0, 3, 5)]
    + [{"type": "trail", "value": v, "label": f"Trailing {v}% from the high close"} for v in (10, 15, 20, 25, 30)]
)
TP_GRID = (
    [{"type": "none", "label": "No take profit"}]
    + [{"type": "pct", "value": v, "label": f"+{v}% above entry"} for v in (10, 15, 20, 25, 30, 40, 50, 75, 100)]
    + [{"type": "atr", "value": v, "label": f"{v}× ATR above entry"} for v in (3, 5, 8, 12)]
)


def _r(x, d=2):
    if x is None:
        return None
    x = float(x)
    return None if math.isnan(x) or math.isinf(x) else round(x, d)


# ======================================================================
# 1. dataset
# ======================================================================
SOURCES = {"public": "Public.com (5 years of daily bars)", "fmp": "FMP (up to 30 years of daily bars)"}


def _ds_path(mode, source="public", years=5):
    if source == "public":
        return paths.DATA_DIR / f"strategy_bt_dataset_{mode}.pkl"          # same file as before v3.6
    return paths.DATA_DIR / f"strategy_bt_dataset_{mode}_{source}{int(years)}y.pkl"


def get_bars(engine, ticker, source="public", years=5):
    """Daily OHLCV for the Strategy Test from the chosen source."""
    if source == "fmp":
        prov = engine.providers_with("daily_bars")
        if not prov:
            raise RuntimeError("FMP isn't connected: add your FMP API key on Data sources")
        return prov[0].daily_bars(ticker, years)
    from .scanner import Context
    return Context(engine, ticker, {"id": "strategy_bt", "fast": 150, "slow": 200}, {"values": {}, "fetched": set()}).get("bars")


def build_dataset(engine, tickers, status, should_stop, log=print, delay=0.1, mode="all", source="public", years=5):
    """Fetch bars + point-in-time fundamentals. Saved to data/ so later runs (other settings, stop tests) are instant."""
    pit_prov = engine.providers_with("pit_fundamentals")
    if not pit_prov:
        raise RuntimeError("Needs SEC EDGAR (point-in-time fundamentals) connected")
    pit_prov = pit_prov[0]
    names = [b for b, _ in BENCHES] + [t for t in tickers if t not in dict(BENCHES)]
    status.update(stage=f"Downloading prices ({'FMP, ' + str(years) + ' years' if source == 'fmp' else 'Public'}) and filings",
                  total=len(names), done=0)
    bars, pit, fails = {}, {}, []
    for i, t in enumerate(names):
        if should_stop():
            break
        status.update(done=i, current=t)
        try:
            df = get_bars(engine, t, source, years)
            if df is None or len(df) < 260:
                continue
            bars[t] = _pack(df)
            if t not in dict(BENCHES):
                pit[t] = pit_prov.pit_fundamentals(t)
        except Exception as e:
            fails.append(f"{t}: {e}")
            if len(fails) >= 8 and not bars:
                raise RuntimeError(fails[0])
        if delay:
            time.sleep(delay)
    ds = {"built": datetime.now().isoformat(timespec="seconds"), "bars": bars, "pit": pit, "mode": mode,
          "source": source, "years": int(years),
          "tickers": [t for t in tickers if t in bars], "fails": fails[:30]}
    if not should_stop():
        add_sector_data(engine, ds, status, should_stop, log=log, save=False)
    save_dataset(ds)
    return ds


def _pack(df):
    idx = df.index.tz_convert(None) if df.index.tz is not None else df.index
    return {"d": np.array(idx.normalize().values, dtype="datetime64[D]"),
            "o": df["open"].values.astype("float32"), "h": df["high"].values.astype("float32"),
            "l": df["low"].values.astype("float32"), "c": df["close"].values.astype("float32"),
            "v": df["volume"].values.astype("float64") if "volume" in df else np.full(len(df), np.nan)}


def save_dataset(ds):
    path = _ds_path(ds.get("mode", "all"), ds.get("source", "public"), ds.get("years", 5))
    paths.DATA_DIR.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(".tmp")
    with open(tmp, "wb") as fh:
        pickle.dump(ds, fh, protocol=pickle.HIGHEST_PROTOCOL)
    os.replace(tmp, path)


def has_macro_data(ds):
    from .macro import MACRO_TICKERS, THEMES
    need = [t for t in MACRO_TICKERS if t != "SPY"] + [e for e, _ in THEMES]
    return all(t in ds["bars"] for t in need)


def has_debt(ds):
    """Datasets from before v3.7 have no debt in their SEC snapshots."""
    for t in (ds.get("tickers") or [])[:20]:
        for snap in ds["pit"].get(t) or []:
            return "debt" in snap and "equity" in snap
    return False


def refresh_pit(engine, ds, status, should_stop, log=print, delay=0.1):
    """Re-download only the SEC snapshots (adds debt/cash/revenue) without re-downloading prices."""
    prov = engine.providers_with("pit_fundamentals")
    if not prov:
        raise RuntimeError("Needs SEC EDGAR connected")
    status.update(stage="Adding debt from SEC filings", total=len(ds["tickers"]), done=0)
    for k, t in enumerate(ds["tickers"]):
        if should_stop():
            break
        status.update(done=k, current=t)
        try:
            ds["pit"][t] = prov[0].pit_fundamentals(t)
        except Exception as e:
            log(f"SEC {t}: {e}")
        if delay:
            time.sleep(delay)
    save_dataset(ds)
    return ds


def has_volume(ds):
    return bool(ds.get("tickers")) and all("v" in ds["bars"][t] for t in ds["tickers"][:5])


def has_earnings(ds):
    return bool(ds.get("earnings"))


def add_earnings(engine, ds, status, should_stop, log=print, save=True, delay=0.09):
    """Earnings report dates for every stock (FMP), for the near-earnings filter. Downloaded once per dataset."""
    prov = [p_ for p_ in engine.providers_with("daily_bars") if hasattr(p_, "earnings_dates")]
    if not prov:
        raise RuntimeError("The earnings filter needs your FMP API key (Data sources)")
    earn = dict(ds.get("earnings") or {})
    todo = [t for t in ds["tickers"] if t not in earn]
    status.update(stage="Downloading earnings dates (FMP)", total=len(todo), done=0)
    fails = 0
    for k, t in enumerate(todo):
        if should_stop():
            break
        status.update(done=k, current=t)
        try:
            earn[t] = prov[0].earnings_dates(t)
        except Exception as e:
            fails += 1
            if fails <= 5:
                log(f"earnings {t}: {e}")
            if "FMP 4" in str(e) and fails >= 3 and not any(earn.values()):
                raise RuntimeError(f"FMP refused the earnings data: {e}")
            earn[t] = []
        if delay:
            time.sleep(delay)
    ds["earnings"] = earn
    ds["earnings_built"] = datetime.now().isoformat(timespec="seconds")
    if save:
        save_dataset(ds)
    return ds


def earnings_index(ds, cal, tickers):
    """{column j: sorted array of calendar indexes of earnings days} (a report on a non-trading day maps to the next session)."""
    earn = ds.get("earnings") or {}
    if not earn:
        return None
    cal_str = np.array([str(d) for d in cal])
    out = {}
    for j, t in enumerate(tickers):
        ds_ = earn.get(t) or []
        if ds_:
            out[j] = np.unique(np.searchsorted(cal_str, np.array(ds_), side="left"))
    return out


def earnings_gap(ei, j, i):
    """(trading days until the next report after day i, trading days since the last report on/before day i)."""
    if ei is None:
        return None, None
    arr = ei.get(j)
    if arr is None or not len(arr):
        return None, None
    k = int(np.searchsorted(arr, i, side="right"))
    nxt = int(arr[k] - i) if k < len(arr) else None
    lst = int(i - arr[k - 1]) if k > 0 else None
    return nxt, lst


def too_near_earnings(a, p):
    """True if the alert is within the near-earnings limits: report in the next N trading days, or in the last M."""
    b, af = int(p.get("earn_before") or 0), int(p.get("earn_after") or 0)
    if b and a.get("earn_next") is not None and a["earn_next"] <= b:
        return True
    if af and a.get("earn_last") is not None and a["earn_last"] <= af:
        return True
    return False


def add_sector_data(engine, ds, status, should_stop, log=print, save=True, delay=0.1):
    """Sector ETF prices + each stock's sector (SEC industry code), for the sector-rotation filter.
    Sectors come from the app's company-info cache first, so only missing ones hit SEC."""
    from .rotation import SECTOR_ETF
    from .scanner import Context

    from .macro import MACRO_TICKERS, THEMES
    src, yrs = ds.get("source", "public"), ds.get("years", 5)
    extra = list(dict.fromkeys(list(SECTOR_ETF.values()) + [e for e, _ in THEMES] + [t for t in MACRO_TICKERS if t != "SPY"]))
    for etf in extra:
        if etf not in ds["bars"]:
            status.update(stage="Downloading sector, theme and macro data", current=etf)
            try:
                df = get_bars(engine, etf, src, yrs)
                if df is not None and len(df):
                    ds["bars"][etf] = _pack(df)
            except Exception as e:
                log(f"sector ETF {etf}: {e}")
    info = store.load("company_info.json", {}) or {}
    sectors = dict(ds.get("sectors") or {})
    missing = [t for t in ds["tickers"] if t not in sectors]
    prov = engine.providers_with("company_info")
    status.update(stage="Looking up sectors", total=len(missing), done=0)
    fetched = 0
    for k, t in enumerate(missing):
        if should_stop():
            break
        status.update(done=k, current=t)
        sec = (info.get(t) or {}).get("sic_sector")
        if sec is None and t not in info and prov:
            try:
                ci = prov[0].company_info(t)
                info[t] = dict(ci, fetched=datetime.now().isoformat(timespec="seconds"))
                sec = ci.get("sic_sector")
                fetched += 1
                if delay:
                    time.sleep(delay)
            except Exception as e:
                log(f"sector {t}: {e}")
                continue
        sectors[t] = sec
    if fetched:
        store.save("company_info.json", info)
    ds["sectors"] = sectors
    if save:
        save_dataset(ds)
    return ds


def load_dataset(mode="all", max_age_days=3, source="public", years=5):
    path = _ds_path(mode, source, years)
    if not path.exists():
        return None
    try:
        with open(path, "rb") as fh:
            ds = pickle.load(fh)
    except Exception:
        return None
    age = datetime.now() - datetime.fromisoformat(ds["built"])
    return ds if age <= timedelta(days=max_age_days) else None


# ======================================================================
# 2. signals
# ======================================================================
def _frames(ds):
    """Align every ticker on SPY's trading calendar -> (dates, {field: 2D array [day, ticker]}, tickers)."""
    cal = ds["bars"]["SPY"]["d"]
    tickers = ds["tickers"]
    n, m = len(cal), len(tickers)
    pos = {d: i for i, d in enumerate(cal.tolist())}
    out = {k: np.full((n, m), np.nan, dtype="float64") for k in "ohlc"}
    for j, t in enumerate(tickers):
        b = ds["bars"][t]
        rows = [pos.get(d) for d in b["d"].tolist()]
        keep = [k for k, r in enumerate(rows) if r is not None]
        ri = np.array([rows[k] for k in keep], dtype=int)
        for f in "ohlc":
            out[f][ri, j] = b[f][keep]
    return cal, out, tickers


def _ma(arr, n, kind):
    import pandas as pd

    df = pd.DataFrame(arr)
    if kind == "SMA":
        return df.rolling(n, min_periods=n).mean().values
    return df.ewm(span=n, adjust=False, ignore_na=True).mean().values


def _fund_masks(ds, cal, tickers, close, p):
    """Daily point-in-time masks for the fundamental rules: each filing counts from the next trading day."""
    n, m = close.shape
    fcf = np.full((n, m), np.nan)
    revok = np.zeros((n, m), dtype=bool)
    epsok = np.zeros((n, m), dtype=bool)
    shares = np.full((n, m), np.nan)
    debt, cash, revttm, equity = (np.full((n, m), np.nan) for _ in range(4))
    cal_str = np.array([str(d) for d in cal])
    for j, t in enumerate(tickers):
        snaps = ds["pit"].get(t) or []
        hist = []
        for s in snaps:
            hist.append(s)
            start = int(np.searchsorted(cal_str, s["known"], side="right"))   # the day AFTER the filing
            if start >= n:
                continue
            rq = int(p.get("rev_quarters", 1))
            recent = sorted(hist, key=lambda x: x["end"], reverse=True)
            ry = [x.get("rev_yoy") for x in recent[:rq]]
            r_ok = len(ry) == rq and all(v is not None and v > p.get("rev_min_pct", 0) for v in ry)
            ups = [x.get("eps_up") for x in recent[:4]]
            e_ok = bool(ups and ups[0]) and sum(1 for u in ups if u) >= int(p.get("eps_min_quarters", 1))
            revok[start:, j] = r_ok
            epsok[start:, j] = e_ok
            latest = recent[0]
            fcf[start:, j] = latest.get("fcf_ttm") if latest.get("fcf_ttm") is not None else np.nan
            if latest.get("shares"):
                shares[start:, j] = latest["shares"]
            for arr, k in ((debt, "debt"), (cash, "cash"), (revttm, "rev_ttm"), (equity, "equity")):
                if k in latest:                                      # None = not reported in that filing
                    arr[start:, j] = latest[k] if latest[k] is not None else np.nan
    mcap = close * shares
    return fcf, revok, epsok, mcap, {"debt": debt, "cash": cash, "rev_ttm": revttm, "equity": equity}


def has_sector_data(ds):
    from .rotation import SECTOR_ETF
    return bool(ds.get("sectors")) and all(etf in ds["bars"] for etf in SECTOR_ETF.values())


def _sector_values(ds, cal, tickers):
    """(days x tickers) float matrix: the stock's sector valuation score (price parts, past data only), NaN if unknown."""
    import pandas as pd

    from .rotation import SECTOR_ETF
    from .sector_filter import price_score_history

    n, m = len(cal), len(tickers)
    out = np.full((n, m), np.nan)
    if not has_sector_data(ds):
        return out
    ser = lambda t: pd.Series(ds["bars"][t]["c"].astype("float64"), index=pd.to_datetime(ds["bars"][t]["d"]))
    spy = ser("SPY")
    idx = pd.to_datetime(cal)
    by_sector = {sec: price_score_history(ser(etf), spy).reindex(idx).values for sec, etf in SECTOR_ETF.items()}
    for j, t in enumerate(tickers):
        sec = ds["sectors"].get(t)
        if sec in by_sector:
            out[:, j] = by_sector[sec]
    return out


def _sector_quadrants(ds, cal, tickers):
    """(days x tickers) int matrix: the stock's sector ETF quadrant vs SPY on each day, using only data up to
    that day. 0 Leading, 1 Weakening, 2 Lagging, 3 Improving, -1 unknown (no sector / no ETF / warming up)."""
    import pandas as pd

    from .rotation import SECTOR_ETF, quadrant_history

    n, m = len(cal), len(tickers)
    out = np.full((n, m), -1, dtype="int8")
    if not has_sector_data(ds):
        return out
    ser = lambda t: pd.Series(ds["bars"][t]["c"].astype("float64"), index=pd.to_datetime(ds["bars"][t]["d"]))
    spy = ser("SPY")
    idx = pd.to_datetime(cal)
    by_sector = {}
    for sec, etf in SECTOR_ETF.items():
        q = quadrant_history(ser(etf), spy).reindex(idx)
        by_sector[sec] = q.fillna(-1).values.astype("int8")
    for j, t in enumerate(tickers):
        sec = ds["sectors"].get(t)
        if sec in by_sector:
            out[:, j] = by_sector[sec]
    return out


def _support_arrays(ds, cal, tickers, fr_, F, S, tf, ts):
    """Support signal masks (days x tickers), if the dataset has volume."""
    from . import support

    if not tickers or "v" not in ds["bars"][tickers[0]]:
        return None
    h, l, c = fr_
    pos = {d: k for k, d in enumerate(cal.tolist())}
    v = np.full(c.shape, np.nan)
    for j, t in enumerate(tickers):
        b = ds["bars"][t]
        rows = [pos.get(d) for d in b["d"].tolist()]
        keep = [k for k, r in enumerate(rows) if r is not None]
        v[np.array([rows[k] for k in keep], dtype=int), j] = b["v"][keep]
    hm = support.hist_masks(h, l, c, v)
    rf, _, _ = support.respected_masks(tf, F, c)
    rs, _, _ = support.respected_masks(ts, S, c)
    return {"sig": {k: hm[k] for k in ("light_pullback", "strong_close", "absorption", "accumulation")},
            "resp_f": rf, "resp_s": rs,
            "fail_f": support.recent_fail_masks(tf, F, c), "fail_s": support.recent_fail_masks(ts, S, c)}


def _series(ds, t):
    import pandas as pd
    b = ds["bars"][t]
    return pd.Series(b["c"].astype("float64"), index=pd.to_datetime(b["d"]))


def _macro_array(ds, cal):
    import pandas as pd

    from .macro import MACRO_TICKERS, score_history
    if any(t not in ds["bars"] for t in MACRO_TICKERS):
        return None
    hist = score_history({t: _series(ds, t) for t in MACRO_TICKERS})
    return hist["score"].reindex(pd.to_datetime(cal)).values


def _theme_arrays(ds, cal, tickers, first):
    """Each stock's theme ETF (matched on the ~year BEFORE alerts start, so no look-ahead) and that theme's
    daily risk count (0-3) -> ({j: etf}, int array days x tickers, -1 = unknown)."""
    import pandas as pd

    from .macro import THEMES, theme_for, theme_history
    etfs = [e for e, _ in THEMES if e in ds["bars"]]
    if not etfs or "SPY" not in ds["bars"]:
        return {}, None
    idx = pd.to_datetime(cal)
    spy = _series(ds, "SPY")
    th = {e: _series(ds, e) for e in etfs}
    risk_by = {e: theme_history(th[e], spy).reindex(idx)["risk"].where(lambda x: x.notna(), -1).values.astype(int) for e in etfs}
    end = idx[max(0, first - 1)]
    out_e, out_r = {}, np.full((len(cal), len(tickers)), -1, dtype=int)
    for j, t in enumerate(tickers):
        e, _ = theme_for(_series(ds, t), th, window=200, end=end)
        if e:
            out_e[j] = e
            out_r[:, j] = risk_by[e]
    return out_e, out_r


def signals(ds, p):
    """Every alert the strategy would have sent. Returns (cal, frames, tickers, alerts, info)."""
    cal, fr, tickers = _frames(ds)
    o, h, l, c = fr["o"], fr["h"], fr["l"], fr["c"]
    kind, fast, slow = p.get("ma_type", "EMA"), int(p.get("fast", 150)), int(p.get("slow", 200))
    F, S = _ma(c, fast, kind), _ma(c, slow, kind)
    tol = 1 + float(p.get("tolerance", 0.5)) / 100
    with np.errstate(invalid="ignore"):
        above = (c > F) & (c > S)
        import pandas as pd
        up = pd.DataFrame(above.astype(float)).shift(1).rolling(20).sum().values >= float(p.get("above_days", 15))
        tf = l <= F * tol
        ts = l <= S * tol
        if p.get("hold", True):
            tf &= c >= F
            ts &= c >= S
    if p.get("new_only", True):
        tf = tf & ~np.vstack([np.zeros((1, tf.shape[1]), bool), tf[:-1]])
        ts = ts & ~np.vstack([np.zeros((1, ts.shape[1]), bool), ts[:-1]])
    lines = p.get("lines", "both")
    if lines == "fast":
        ts[:] = False
    elif lines == "slow":
        tf[:] = False
    seen = np.cumsum(~np.isnan(c), axis=0)
    warm = seen >= max(slow, 60) + 20          # averages settled
    mask = up & (tf | ts) & warm
    fcf, revok, epsok, mcap, ex = _fund_masks(ds, cal, tickers, c, p)
    with np.errstate(invalid="ignore"):
        if p.get("use_fcf", True):
            mask &= fcf > 0
        if p.get("use_rev", True):
            mask &= revok
        if p.get("use_eps", True):
            mask &= epsok
        if p.get("min_cap_b"):
            mask &= mcap >= float(p["min_cap_b"]) * 1e9
    # debt as % of market cap (that day) and % of trailing-12-month revenue (latest filing known that day)
    debt_pm = debt_pr = debt_de = neg_eq = None
    if has_debt(ds):
        d_ = ex["debt"] - (np.nan_to_num(ex["cash"]) if p.get("debt_net") else 0)
        if p.get("debt_net"):
            d_ = np.where(np.isnan(ex["debt"]), np.nan, np.maximum(d_, 0))
        with np.errstate(invalid="ignore", divide="ignore"):
            debt_pm = d_ / mcap * 100
            debt_pr = np.where(ex["rev_ttm"] > 0, d_ / ex["rev_ttm"] * 100, np.nan)
            debt_de = np.where(ex["equity"] > 0, d_ / ex["equity"], np.nan)
            neg_eq = ex["equity"] <= 0
        if p.get("use_debt"):
            fin = np.array([(ds.get("sectors") or {}).get(t) in ("Financials", "Real estate") for t in tickers]) \
                if p.get("debt_skip_fin", True) else np.zeros(len(tickers), bool)
            no_data = np.isnan(ex["debt"])
            ok = np.ones_like(mask)
            with np.errstate(invalid="ignore"):
                if float(p.get("max_debt_mcap") or 0) > 0:
                    ok &= ~(debt_pm > float(p["max_debt_mcap"]))
                if float(p.get("max_debt_rev") or 0) > 0:
                    ok &= ~(debt_pr > float(p["max_debt_rev"]))
                if float(p.get("max_debt_equity") or 0) > 0:
                    ok &= ~(debt_de > float(p["max_debt_equity"]))
                if p.get("debt_block_neg_equity", True):
                    ok &= ~neg_eq
            if p.get("debt_no_data") == "block":
                ok &= ~no_data
            mask &= ok | fin[None, :]
    # ATR(14) for ATR stops
    prev_c = np.vstack([np.full((1, c.shape[1]), np.nan), c[:-1]])
    tr = np.nanmax(np.stack([h - l, np.abs(h - prev_c), np.abs(l - prev_c)]), axis=0)
    atr = pd.DataFrame(tr).rolling(14, min_periods=10).mean().values
    sq = _sector_quadrants(ds, cal, tickers)
    sv = _sector_values(ds, cal, tickers)
    sup = _support_arrays(ds, cal, tickers, fr_=(h, l, c), F=F, S=S, tf=tf & up, ts=ts & up)
    mac = _macro_array(ds, cal)
    first_ = int(np.argmax(warm.any(axis=1))) if warm.any() else 0
    th_etf, th_risk = _theme_arrays(ds, cal, tickers, first_)
    from .rotation import QUADRANTS
    from . import beta as beta_
    spy_c = None
    if "SPY" in ds["bars"]:
        bb = ds["bars"]["SPY"]
        pos_ = {d: k for k, d in enumerate(bb["d"].tolist())}
        spy_c = np.array([bb["c"][pos_[d]] if d in pos_ else np.nan for d in cal.tolist()], dtype="float64")
    ei = earnings_index(ds, cal, tickers)
    from . import entry_quality as eq
    with np.errstate(invalid="ignore"):
        tn_f = eq.touch_counts(eq.episode_starts(l <= F * tol))      # touch number of each line, last 12 months
        tn_s = eq.touch_counts(eq.episode_starts(l <= S * tol))
    from .rotation import SECTOR_ETF
    sec_c = {}

    def sector_close(t):
        etf = SECTOR_ETF.get((ds.get("sectors") or {}).get(t))
        if not etf or etf not in ds["bars"]:
            return None
        if etf not in sec_c:
            bb_ = ds["bars"][etf]
            ps_ = {d: k for k, d in enumerate(bb_["d"].tolist())}
            sec_c[etf] = np.array([bb_["c"][ps_[d]] if d in ps_ else np.nan for d in cal.tolist()], dtype="float64")
        return sec_c[etf]
    sp_days, rl_days, sl_days = int(p.get("speed_days") or 5), int(p.get("rel_days") or 20), int(p.get("slope_days") or 60)
    days, cols = np.nonzero(mask)
    alerts = []
    for i, j in sorted(zip(days.tolist(), cols.tolist())):
        line = "slow" if ts[i, j] else "fast"
        both = bool(tf[i, j] and ts[i, j])
        alerts.append({"i": i, "j": j, "ticker": tickers[j], "line": "both" if both else line,
                       "entry": float(c[i, j]), "atr": float(atr[i, j]) if not np.isnan(atr[i, j]) else None,
                       "mcap": _r(mcap[i, j] / 1e9, 1) if not np.isnan(mcap[i, j]) else None,
                       "sector": (ds.get("sectors") or {}).get(tickers[j]),
                       "sq": QUADRANTS[sq[i, j]] if sq[i, j] >= 0 else None,
                       "sv": None if np.isnan(sv[i, j]) else float(sv[i, j]),
                       "debt_mcap": None if debt_pm is None or np.isnan(debt_pm[i, j]) else _r(debt_pm[i, j], 0),
                       "debt_rev": None if debt_pr is None or np.isnan(debt_pr[i, j]) else _r(debt_pr[i, j], 0),
                       "debt_de": None if debt_de is None or np.isnan(debt_de[i, j]) else _r(debt_de[i, j], 2),
                       "neg_eq": bool(neg_eq[i, j]) if neg_eq is not None else False,
                       "sig": {k: bool(a_[i, j]) for k, a_ in sup["sig"].items()} if sup else None,
                       "no_repeat": (not bool(sup["fail_s" if ts[i, j] else "fail_f"][i, j])) if sup else None,
                       "macro": None if mac is None or np.isnan(mac[i]) else float(mac[i]),
                       "theme": th_etf.get(j), "theme_risk": None if th_risk is None or th_risk[i, j] < 0 else int(th_risk[i, j]),
                       "beta": _r(beta_.from_prices(c[max(0, i - beta_.WINDOW):i + 1, j], spy_c[max(0, i - beta_.WINDOW):i + 1]), 2) if spy_c is not None else None,
                       **extension(c[:, j], F[:, j], S[:, j], i, int(p.get("ext_days") or 60)),
                       **dict(zip(("earn_next", "earn_last"), earnings_gap(ei, j, i))),
                       **dict(zip(("pb_drop", "pb_gap"), (_r(x_, 1) for x_ in eq.pullback(c[:, j], o[:, j], i, sp_days)))),
                       "rel_spy": _r(eq.relative(c[:, j], spy_c, i, rl_days), 1),
                       "rel_sec": _r(eq.relative(c[:, j], sector_close(tickers[j]), i, rl_days), 1),
                       "touch_n": int(tn_s[i, j] if ts[i, j] else tn_f[i, j]),
                       "slow_slope": _r(eq.slope(S[:, j], i, sl_days), 1)})
        if sup:
            a_ = alerts[-1]
            a_["sig"]["respected"] = bool(sup["resp_s" if ts[i, j] else "resp_f"][i, j])
    first = int(np.argmax(warm.any(axis=1))) if warm.any() else 0
    info = {"first_day": str(cal[first]), "last_day": str(cal[-1]), "days": len(cal) - first, "start_index": first}
    return cal, {"o": o, "h": h, "l": l, "c": c, "F": F, "S": S}, tickers, alerts, info


# ======================================================================
# 3. trades
# ======================================================================
def _target(alert, fr, tp, seg, i, j):
    """First day the take profit fills -> (index, price) or (None, None). Gap up through it = fill at the open."""
    t = (tp or {}).get("type", "none")
    entry = alert["entry"]
    if t == "pct":
        level = entry * (1 + tp["value"] / 100)
    elif t == "atr" and alert.get("atr"):
        level = entry + tp["value"] * alert["atr"]
    elif t == "price" and tp.get("value"):
        level = float(tp["value"])
    else:
        return None, None
    o, h = fr["o"][seg, j], fr["h"][seg, j]
    idx = np.nonzero(h >= level)[0]
    if not len(idx):
        return None, None
    k = idx[0]
    op = o[k]
    return i + 1 + k, (max(op, level) if not np.isnan(op) else level)


def simulate(alert, fr, stop, hold, tp=None):
    """One trade with one stop rule and an optional take profit -> (exit_index, exit_price, reason);
    reason in hold|stop|target|open. Stop and target on the same day = the stop (the cautious assumption)."""
    i, j, entry = alert["i"], alert["j"], alert["entry"]
    n = fr["c"].shape[0]
    end = min(n - 1, i + hold)
    if end <= i:
        return i, entry, "open"
    seg = slice(i + 1, end + 1)
    th, tpx = _target(alert, fr, tp, seg, i, j)
    hit, price = _stop_hit(alert, fr, stop, seg, i, j)
    if th is not None and (hit is None or th < hit):
        return int(th), float(tpx), "target"
    if hit is not None:
        return int(hit), float(price), "stop"
    last = end
    while last > i and np.isnan(fr["c"][last, j]):
        last -= 1
    return int(last), float(fr["c"][last, j]), ("hold" if i + hold <= n - 1 else "open")


def _stop_hit(alert, fr, stop, seg, i, j):
    entry = alert["entry"]
    o, l, c = fr["o"][seg, j], fr["l"][seg, j], fr["c"][seg, j]
    t = stop["type"]
    hit, price = None, None
    if t in ("pct", "atr"):
        if t == "pct":
            level = entry * (1 - stop["value"] / 100)
        else:
            if not alert["atr"]:
                level = None
            else:
                level = entry - stop["value"] * alert["atr"]
        if level is not None:
            idx = np.nonzero(l <= level)[0]
            if len(idx):
                k = idx[0]
                hit = i + 1 + k
                op = o[k]
                price = min(op, level) if not np.isnan(op) else level      # gap down = fill at the open
    elif t == "line":
        ma = fr["S"][seg, j] if alert["line"] in ("slow", "both") else fr["F"][seg, j]
        idx = np.nonzero(c < ma * (1 - stop["value"] / 100))[0]
        if len(idx):
            hit = i + 1 + idx[0]
            price = c[idx[0]]
    elif t == "slow":
        idx = np.nonzero(c < fr["S"][seg, j] * (1 - stop["value"] / 100))[0]
        if len(idx):
            hit = i + 1 + idx[0]
            price = c[idx[0]]
    elif t == "trail":
        hw = np.maximum.accumulate(np.where(np.isnan(c), -np.inf, np.maximum(c, entry)))
        idx = np.nonzero(c <= hw * (1 - stop["value"] / 100))[0]
        if len(idx):
            hit = i + 1 + idx[0]
            price = c[idx[0]]
    elif t == "price" and stop.get("value"):
        idx = np.nonzero(l <= float(stop["value"]))[0]
        if len(idx):
            k = idx[0]
            hit = i + 1 + k
            price = min(o[k], float(stop["value"])) if not np.isnan(o[k]) else float(stop["value"])
    if hit is not None and not np.isnan(price):
        return hit, price
    return None, None


def _bench_ret(bench_c, i, k):
    a, b = bench_c[i], bench_c[k]
    return (b / a - 1) * 100 if a and not np.isnan(a) and not np.isnan(b) else None


def trade_stats(trades):
    done = [t for t in trades if t["reason"] != "open"]
    rets = [t["ret"] for t in done]
    if not rets:
        return {"n": 0, "open": len(trades)}
    wins, losses = [r for r in rets if r > 0], [r for r in rets if r <= 0]
    srt = sorted(rets)
    med = srt[len(srt) // 2] if len(srt) % 2 else (srt[len(srt) // 2 - 1] + srt[len(srt) // 2]) / 2
    out = {"n": len(done), "open": len(trades) - len(done), "win": _r(100 * len(wins) / len(rets), 1),
           "avg": _r(np.mean(rets)), "median": _r(med), "avg_win": _r(np.mean(wins)) if wins else None,
           "avg_loss": _r(np.mean(losses)) if losses else None,
           "pf": _r(sum(wins) / abs(sum(losses)), 2) if losses and sum(losses) != 0 else None,
           "best": _r(srt[-1]), "worst": _r(srt[0]), "days": _r(np.mean([t["days"] for t in done]), 0),
           "stopped": _r(100 * sum(1 for t in done if t["reason"] == "stop") / len(done), 1),
           "targets": _r(100 * sum(1 for t in done if t["reason"] == "target") / len(done), 1)}
    for b, _ in BENCHES:
        ex = [t["ret"] - t["bench"][b] for t in done if t["bench"].get(b) is not None]
        out[f"vs_{b}"] = _r(np.mean(ex)) if ex else None
        out[f"beat_{b}"] = _r(100 * sum(1 for x in ex if x > 0) / len(ex), 1) if ex else None
    return out


def extension(c, F, S, i, days=60):
    """How stretched the trend is on day i: fast line vs slow line (%), and the highest close of the last `days`
    days vs the slow line under it (%). Big numbers = the stock already ran far above its slow line."""
    f, sl = F[i], S[i]
    spread = (f / sl - 1) * 100 if sl and not np.isnan(f) and not np.isnan(sl) else None
    k0 = max(0, i - days + 1)
    with np.errstate(divide="ignore", invalid="ignore"):
        r = c[k0:i + 1] / S[k0:i + 1]
    r = r[np.isfinite(r)]
    peak = (float(r.max()) - 1) * 100 if len(r) else None
    return {"ext_spread": _r(spread, 1), "ext_peak": _r(peak, 1)}


def beta_factor(b):
    """Multiplier for beta-adjusted stretch: beta clamped to 0.5–3 (unknown beta = 1)."""
    return 1.0 if b is None else min(3.0, max(0.5, float(b)))


def too_extended(a, p):
    """True if the alert breaks the 'not overextended' limits (0 = that limit is off).
    With ext_beta on, each stretch is multiplied by the stock's beta first, so a beta-2 stock gets half the room:
    the higher the beta, the harder it tends to fall back."""
    ms, mp = float(p.get("ext_max_spread") or 0), float(p.get("ext_max_peak") or 0)
    k = beta_factor(a.get("beta")) if p.get("ext_beta") else 1.0
    if ms and a.get("ext_spread") is not None and a["ext_spread"] * k > ms:
        return True
    if mp and a.get("ext_peak") is not None and a["ext_peak"] * k > mp:
        return True
    return False


def search_days(days, frm=None, to=None, ticker=None, limit=1500):
    """Alert days between two dates (inclusive, 'YYYY-MM-DD', either can be blank), optionally one ticker.
    Returns (days newest first, summary of the matching trades)."""
    frm, to = (frm or "").strip()[:10], (to or "").strip()[:10]
    if frm and to and frm > to:
        frm, to = to, frm
    tk = (ticker or "").strip().upper()
    out = []
    for d in days or []:
        if (frm and d["date"] < frm) or (to and d["date"] > to):
            continue
        al = [a for a in d["alerts"] if not tk or a["ticker"].upper() == tk]
        if al:
            out.append({"date": d["date"], "alerts": al})
    out.sort(key=lambda d: d["date"], reverse=True)
    rows = [a for d in out for a in d["alerts"] if a.get("ret") is not None]
    done = [a for a in rows if a.get("reason") != "open"]
    vs = [a["vs_SPY"] for a in rows if a.get("vs_SPY") is not None]
    summ = {"days": len(out), "alerts": sum(len(d["alerts"]) for d in out), "finished": len(done), "open": len(rows) - len(done),
            "win": _r(100 * sum(1 for a in done if a["ret"] > 0) / len(done), 1) if done else None,
            "avg": _r(sum(a["ret"] for a in done) / len(done)) if done else None,
            "avg_all": _r(sum(a["ret"] for a in rows) / len(rows)) if rows else None,
            "vs_SPY": _r(sum(vs) / len(vs)) if vs else None,
            "beat_spy": _r(100 * sum(1 for v in vs if v > 0) / len(vs), 1) if vs else None,
            "best": max(rows, key=lambda a: a["ret"])["ticker"] if rows else None,
            "first": out[-1]["date"] if out else None, "last": out[0]["date"] if out else None}
    return out[:limit], summ


def year_curves(days, cal, daily, skip=None, capital=10_000.0):
    """Each calendar year on its own: every line restarted at $10k on the last close before the year, daily points.
    -> {"2024": {"t": [...], "lines": {name: [...]}, "stats": {name: {"ret", "maxdd", "final"}}}}"""
    out = {}
    by_year = {}
    for k, d in enumerate(days):
        by_year.setdefault(str(cal[d])[:4], []).append(k)
    for y, ks in sorted(by_year.items()):
        if skip is not None and skip[days[ks[0]]]:
            continue
        base_day = days[ks[0] - 1] if ks[0] > 0 else days[ks[0]]
        yd = [days[k] for k in ks]
        lines, stats = {}, {}
        for name, m in daily.items():
            b0 = m.get(yd[0] - 1)                 # the close right before the year (prices keep left-out days)
            if not b0:
                b0 = m.get(base_day)              # spliced curves: last kept day (flat across a left-out year)
            if b0 is None or not b0:
                b0 = next((m[d] for d in yd if m.get(d)), None)
            if not b0:
                continue
            vals = [m.get(d) for d in yd]
            if not any(v is not None for v in vals):
                continue
            eq = [None if v is None else capital * v / b0 for v in vals]
            lines[name] = [None if v is None else round(v, 0) for v in eq]
            pk, dd = capital, 0.0
            for v in eq:
                if v is None:
                    continue
                pk = max(pk, v)
                dd = min(dd, (v / pk - 1) * 100)
            last = next(v for v in reversed(eq) if v is not None)
            stats[name] = {"ret": _r((last / capital - 1) * 100), "maxdd": _r(dd), "final": _r(last, 0)}
        if lines:
            out[y] = {"t": [str(cal[d]) for d in yd], "lines": lines, "stats": stats,
                      "partial": len(yd) < 240, "from": str(cal[yd[0]]), "to": str(cal[yd[-1]])}
    return out


def search_winners_losers(days, ticker=None, frm=None, to=None):
    """Best / worst trades among the alerts matching a ticker and/or an alert-date range (uses the saved alert days)."""
    sel, _ = search_days(days, frm, to, ticker, limit=10 ** 9)
    rows = []
    for d in sel:
        for a in d["alerts"]:
            if a.get("ret") is None:
                continue
            vs = a.get("vs_SPY")
            rows.append({"date": d["date"], "ticker": a["ticker"], "line": a.get("line"), "entry": a.get("entry"),
                         "exit": _r(a["entry"] * (1 + a["ret"] / 100)) if a.get("entry") else None,
                         "exit_date": a.get("exit_date"), "days": a.get("days"), "reason": a.get("reason"), "sector": a.get("sector"),
                         "ret": a["ret"], "spy": _r(a["ret"] - vs) if vs is not None else None, "vs_SPY": vs, "opt_ret": a.get("opt_ret")})
    return winners_losers(rows)


def filter_report(trades, p, cal, has_earn=False):
    """Each filter on its own, at the numbers set in the rules (or sensible defaults if it's off), vs every alert:
    trades kept, their win rate / avg / profit factor, the change vs all alerts, and in how many years it helped."""
    from . import entry_quality as eq
    from . import sector_filter as sf
    from .optimizer import apply_filters
    if not trades:
        return {"rows": [], "base": {}}
    base = trade_stats(trades)
    years = sorted({str(cal[t["a"]["i"]])[:4] for t in trades})
    by_year_all = {y: trade_stats([t for t in trades if str(cal[t["a"]["i"]])[:4] == y]) for y in years}
    g = lambda k, d: p.get(k) if p.get(k) not in (None, "", 0) else d
    sk = sf.key(p.get("sector_filter")) if sf.key(p.get("sector_filter")) != "off" else "leading_improving"
    tests = [
        ("Sector filter", sf.label(sk), "sector_filter", lambda a: sf.passes(sk, a.get("sq"), a.get("sv"))),
        ("Macro", f"score ≥ {g('macro_min', -2)}", "macro_min", lambda a: a.get("macro") is not None and a["macro"] >= float(g("macro_min", -2))),
        ("Theme rotation", f"under {g('theme_max_risk', 2)} warnings", "theme_max_risk", lambda a: a.get("theme_risk") is None or a["theme_risk"] < int(g("theme_max_risk", 2))),
        ("Not overextended", f"fast ≤ {g('ext_max_spread', 10)}% above slow" + (", × beta" if p.get("ext_beta") else ""), "use_ext",
         lambda a: not too_extended(a, {"ext_max_spread": g("ext_max_spread", 10), "ext_max_peak": p.get("ext_max_peak"), "ext_beta": p.get("ext_beta")})),
        ("Beta", f"{g('beta_min', 0)}–{g('beta_max', 2)}", "use_beta",
         lambda a: a.get("beta") is not None and (not g("beta_min", 0) or a["beta"] >= float(g("beta_min", 0))) and a["beta"] <= float(g("beta_max", 2))),
        ("Debt", "rules' debt limits", "use_debt", lambda a: bool(apply_filters([a], {"debt": {"mcap": g("max_debt_mcap", 50), "rev": g("max_debt_rev", 150), "de": g("max_debt_equity", 1.5)}}))),
        ("Pullback speed", f"fell ≤ {g('speed_max_drop', 10)}% in {g('speed_days', 5)}d" + (f", gap ≤ {p['speed_max_gap']}%" if p.get("speed_max_gap") else ""), "use_speed",
         lambda a: not eq.too_fast(a, {"speed_max_drop": g("speed_max_drop", 10), "speed_max_gap": p.get("speed_max_gap")})),
        ("Weakness vs SPY", f"≤ {g('rel_max_spy', 8)} pts weaker in {g('rel_days', 20)}d", "use_rel", lambda a: not eq.too_weak(a, {"rel_max_spy": g("rel_max_spy", 8), "rel_max_sec": p.get("rel_max_sec")})),
        ("Touch number", f"touch #{g('touch_max', 2)} or earlier", "use_touches", lambda a: not eq.too_many_touches(a, {"touch_max": g("touch_max", 2)})),
        ("Slow-line slope", f"≥ {g('slope_min', 2)}% over {g('slope_days', 60)}d", "use_slope", lambda a: not eq.too_flat(a, {"slope_min": g("slope_min", 2)})),
    ]
    sup_names = {"light_pullback": "Pullback on light volume", "strong_close": "Closed strong at the line", "absorption": "Heavy volume, but it held",
                 "accumulation": "Accumulation into the pullback", "respected": "Line held before"}
    if trades and trades[0]["a"].get("sig") is not None:
        for k, nm in sup_names.items():
            tests.append((nm, "support check", "require:" + k, lambda a, k=k: bool((a.get("sig") or {}).get(k))))
    if has_earn:
        tests.append(("Near earnings", f"no report within {g('earn_before', 10)}d", "use_earn",
                      lambda a: not too_near_earnings(a, {"earn_before": g("earn_before", 10), "earn_after": p.get("earn_after")})))
    out = []
    for name, setting, key, keep in tests:
        try:
            kept = [t for t in trades if keep(t["a"])]
        except Exception:
            continue
        if not kept or len(kept) == len(trades):
            continue
        ks = trade_stats(kept)
        helped = tot = 0
        for y in years:
            ky = [t for t in kept if str(cal[t["a"]["i"]])[:4] == y]
            a_, k_ = by_year_all[y], trade_stats(ky) if ky else {}
            if a_.get("win") is not None and k_.get("win") is not None and len(ky) >= 5:
                tot += 1
                helped += k_["win"] > a_["win"]
        on = (key.split(":", 1)[1] in (p.get("require") or [])) if key.startswith("require:") else \
            (sf.key(p.get("sector_filter")) != "off" if key == "sector_filter" else (p.get(key) not in (None, "", False, 0)))
        out.append({"name": name, "key": key, "setting": setting, "on": bool(on), "kept": len(kept), "removed": len(trades) - len(kept),
                    "kept_pct": _r(100 * len(kept) / len(trades), 0), "win": ks.get("win"), "avg": ks.get("avg"), "pf": ks.get("pf"),
                    "vs_SPY": ks.get("vs_SPY"),
                    "d_win": _r((ks.get("win") or 0) - (base.get("win") or 0), 1) if ks.get("win") is not None and base.get("win") is not None else None,
                    "d_avg": _r((ks.get("avg") or 0) - (base.get("avg") or 0), 2) if ks.get("avg") is not None and base.get("avg") is not None else None,
                    "d_pf": _r((ks.get("pf") or 0) - (base.get("pf") or 0), 2) if ks.get("pf") is not None and base.get("pf") is not None else None,
                    "years_helped": helped, "years": tot})
    out.sort(key=lambda r_: -(r_["d_win"] if r_["d_win"] is not None else -999))
    return {"rows": out, "base": {"n": base.get("n"), "win": base.get("win"), "avg": base.get("avg"), "pf": base.get("pf")}}


def winners_losers(rows, n=100):
    """Best and worst trades by return (finished and still-open), each list best/worst first."""
    ok = [r for r in rows if r.get("ret") is not None]
    ok.sort(key=lambda r: (r["ret"], r.get("vs_SPY") or 0), reverse=True)
    win = [r for r in ok if r["ret"] > 0][:n]
    lose = [r for r in reversed(ok) if r["ret"] <= 0][:n]
    done = [r for r in ok if r["reason"] != "open"]
    vs = sorted((r for r in ok if r.get("vs_SPY") is not None), key=lambda r: r["vs_SPY"], reverse=True)
    return {"winners": win, "losers": lose,
            "winners_spy": [r for r in vs if r["vs_SPY"] > 0][:n], "losers_spy": [r for r in reversed(vs) if r["vs_SPY"] <= 0][:n], "n": len(ok), "n_win": sum(1 for r in ok if r["ret"] > 0),
            "n_lose": sum(1 for r in ok if r["ret"] <= 0), "n_open": len(ok) - len(done),
            "beat_spy": sum(1 for r in ok if (r.get("vs_SPY") or 0) > 0)}


def run_trades(alerts, fr, bench, stop, hold, tp=None):
    trades = []
    for a in alerts:
        k, px, reason = simulate(a, fr, stop, hold, tp)
        ret = (px / a["entry"] - 1) * 100
        trades.append({"a": a, "exit_i": k, "exit": px, "reason": reason, "ret": ret, "days": k - a["i"],
                       "bench": {b: _bench_ret(bench[b], a["i"], k) for b in bench}})
    return trades


# ======================================================================
# 4. portfolio
# ======================================================================
def skip_mask(cal, excl):
    """True on every day of a left-out year (or None if no years are left out)."""
    excl = {int(y) for y in (excl or [])}
    if not excl:
        return None
    return np.array([int(str(d)[:4]) in excl for d in cal], dtype=bool)


def splice(eq, start_i, skip, capital=10_000.0):
    """Remove left-out days from an equity curve: the curve only moves on kept days, so whatever happened during a
    left-out year (gains or losses) is ignored, as if those days never existed. Returns (curve, kept day indexes)."""
    if skip is None:
        return list(eq), list(range(start_i, start_i + len(eq)))
    out, days, v, prev = [], [], capital, capital
    for k, x in enumerate(eq):
        d = start_i + k
        if x is None or (isinstance(x, float) and math.isnan(x)):
            continue
        if not skip[d]:
            v *= x / prev if prev else 1.0
            out.append(v)
            days.append(d)
        prev = x
    return out, days


def eq_stats(eq, capital=10_000.0):
    if not eq:
        return {"total": 0, "cagr": None, "maxdd": 0, "calmar": None, "final": capital}
    a = np.asarray(eq, dtype="float64")
    years = max(1e-9, len(a) / 252)
    maxdd = min(0.0, float(((a / np.maximum.accumulate(np.maximum(a, 1e-9))) - 1).min() * 100))
    cagr = ((a[-1] / capital) ** (1 / years) - 1) * 100 if a[-1] > 0 else None
    return {"total": _r((a[-1] / capital - 1) * 100), "cagr": _r(cagr), "maxdd": _r(maxdd),
            "calmar": _r(cagr / abs(maxdd), 2) if cagr is not None and maxdd < 0 else None, "final": _r(a[-1], 0)}


def portfolio(trades, fr, start_i, n_days, slots=10, capital=10_000.0, valuer=None, skip=None):
    """Equal slots: each new alert gets 1/slots of current equity if a slot is free; else it's skipped.
    valuer(position, day) -> price per unit, for things that aren't priced at the stock's close (calls).
    skip: day mask of left-out years; those days are cut out of the curve and its stats (see splice)."""
    c = fr["c"]
    by_entry = {}
    for t in trades:
        by_entry.setdefault(t["a"]["i"], []).append(t)
    cash, open_pos, equity = capital, [], []
    taken = skipped = 0
    peak, maxdd = capital, 0.0
    invested_days = 0
    for d in range(start_i, n_days):
        # exits at today's prices
        still = []
        for pz in open_pos:
            if pz["t"]["exit_i"] <= d:
                cash += pz["sh"] * pz["t"]["exit"]
            else:
                still.append(pz)
        open_pos = still
        val = cash
        for pz in open_pos:
            px = valuer(pz, d) if valuer else c[d, pz["j"]]
            pz["last"] = px if px is not None and not np.isnan(px) else pz["last"]
            val += pz["sh"] * pz["last"]
        # new entries at today's close
        for t in sorted(by_entry.get(d, []), key=lambda x: -(x["a"]["mcap"] or 0)):
            if len(open_pos) >= slots or any(pz["j"] == t["a"]["j"] for pz in open_pos):
                skipped += 1
                continue
            alloc = min(cash, val / slots)
            if alloc <= 0:
                skipped += 1
                continue
            px0 = t.get("entry_px", t["a"]["entry"])
            sh = alloc / px0
            cash -= alloc
            open_pos.append({"t": t, "j": t["a"]["j"], "sh": sh, "last": px0})
            taken += 1
        if open_pos:
            invested_days += 1
        peak = max(peak, val)
        maxdd = min(maxdd, (val / peak - 1) * 100)
        equity.append(val)
    if skip is not None:
        equity, kept = splice(equity, start_i, skip, capital)
        es = eq_stats(equity, capital)
        return dict(es, equity=equity, equity_days=kept, taken=taken, skipped=skipped,
                    exposure=_r(100 * invested_days / max(1, n_days - start_i), 1))
    years = max(1e-9, (n_days - start_i) / 252)
    total = (equity[-1] / capital - 1) * 100 if equity else 0
    cagr = ((equity[-1] / capital) ** (1 / years) - 1) * 100 if equity and equity[-1] > 0 else None
    return {"equity": equity, "total": _r(total), "cagr": _r(cagr), "maxdd": _r(maxdd), "taken": taken,
            "skipped": skipped, "exposure": _r(100 * invested_days / max(1, n_days - start_i), 1),
            "calmar": _r(cagr / abs(maxdd), 2) if cagr is not None and maxdd < 0 else None, "final": _r(equity[-1] if equity else capital, 0)}


def buy_hold(series, start_i, capital=10_000.0, skip=None):
    if skip is not None:
        raw = series[start_i:]
        ok = ~np.isnan(raw)
        if not ok.any():
            return None
        first = raw[ok][0]
        eq, kept = splice([capital * x / first if not np.isnan(x) else None for x in raw], start_i, skip, capital)
        if not eq:
            return None
        return dict(eq_stats(eq, capital), equity=eq, equity_days=kept)
    s = series[start_i:]
    s = s[~np.isnan(s)]
    if not len(s):
        return None
    eq = capital * s / s[0]
    peak = np.maximum.accumulate(eq)
    years = max(1e-9, len(s) / 252)
    return {"equity": eq.tolist(), "total": _r((eq[-1] / capital - 1) * 100), "maxdd": _r(((eq / peak) - 1).min() * 100),
            "cagr": _r(((eq[-1] / capital) ** (1 / years) - 1) * 100), "final": _r(eq[-1], 0)}


# ======================================================================
# 5. everything together
# ======================================================================
PERIODS = [("all", "All the data"), ("20y", "Past 20 years"), ("15y", "Past 15 years"), ("10y", "Past 10 years"), ("5y", "Past 5 years"), ("3y", "Past 3 years"), ("2y", "Past 2 years"),
           ("1y", "Past year"), ("ytd", "Year to date"), ("6m", "Past 6 months"), ("3m", "Past 3 months"), ("1m", "Past month")]
_PERIOD_DAYS = {"20y": 5040, "15y": 3780, "10y": 2520, "5y": 1260, "3y": 756, "2y": 504, "1y": 252, "6m": 126, "3m": 63, "1m": 21}


def period_start(cal, warm_start, period):
    """Index of the first alert day for the chosen test period (never before the averages have settled)."""
    period = period or "all"
    label = dict(PERIODS).get(period, "All the data")
    n = len(cal)
    if period == "ytd":
        y = str(cal[-1])[:4]
        i = next((k for k in range(n) if str(cal[k])[:4] == y), n - 1)
    elif period in _PERIOD_DAYS:
        i = max(0, n - _PERIOD_DAYS[period])
        have = (n - warm_start) / 252
        if i < warm_start and have < _PERIOD_DAYS[period] / 252 - 1.2:    # asked for clearly more history than the data has
            label = f"{label} (only {have:.1f} years of alerts in this data{': pick FMP with more years' if period in ('10y', '15y', '20y') else ''})"
    else:
        i = warm_start
    return max(int(warm_start), int(i)), label


def run(ds, p, status=None):
    st = status if status is not None else {}
    st.update(stage="Finding every past alert")
    from . import sector_filter as sf
    from .rotation import QUADRANTS
    cal, fr, tickers, alerts, info = signals(ds, p)
    # test period + excluded years (alerts outside are dropped; the equity curve starts at the period start)
    ps, period_label = period_start(cal, info["start_index"], p.get("period"))
    excl = sorted({int(y) for y in (p.get("exclude_years") or []) if str(y).strip().isdigit()})
    alerts = [a for a in alerts if a["i"] >= ps and int(str(cal[a["i"]])[:4]) not in excl]
    skip = skip_mask(cal, excl)
    info = dict(info, start_index=ps, first_day=str(cal[ps]), days=len(cal) - ps, period=period_label,
                exclude_years=excl, years_available=sorted({int(str(d)[:4]) for d in cal[info["start_index"]:]}))
    sec_key = sf.key(p.get("sector_filter"))
    sec_ok = has_sector_data(ds)
    if sec_key != "off" and not sec_ok:
        raise RuntimeError("The sector filter needs sector data: run again (it downloads sectors once)")
    all_alerts = alerts
    if sec_key != "off":
        alerts = [a for a in alerts if sf.passes(sec_key, a.get("sq"), a.get("sv"))]
    # support / macro / theme filters
    require = [k for k in (p.get("require") or []) if k]
    has_sup = bool(all_alerts) and all_alerts[0].get("sig") is not None
    if require and not has_sup:
        raise RuntimeError("The support filters need volume data: tick 'Re-download data' and run again")
    for k in require:
        alerts = [a for a in alerts if (a.get("no_repeat") if k == "no_repeat" else (a.get("sig") or {}).get(k))]
    if p.get("macro_min") not in (None, "", "off"):
        mm = float(p["macro_min"])
        alerts = [a for a in alerts if a.get("macro") is not None and a["macro"] >= mm]
    if p.get("theme_max_risk") not in (None, "", "off"):
        tr = int(p["theme_max_risk"])
        alerts = [a for a in alerts if a.get("theme_risk") is None or a["theme_risk"] < tr]
    if p.get("use_ext"):
        alerts = [a for a in alerts if not too_extended(a, p)]
    from . import entry_quality as eq
    if p.get("use_speed"):
        alerts = [a for a in alerts if not eq.too_fast(a, p)]
    if p.get("use_rel"):
        alerts = [a for a in alerts if not eq.too_weak(a, p)]
    if p.get("use_touches"):
        alerts = [a for a in alerts if not eq.too_many_touches(a, p)]
    if p.get("use_slope"):
        alerts = [a for a in alerts if not eq.too_flat(a, p)]
    if p.get("use_earn"):
        if not has_earnings(ds):
            raise RuntimeError("The earnings filter needs earnings dates: add your FMP key on Data sources and run again")
        alerts = [a for a in alerts if not too_near_earnings(a, p)]
    bmin, bmax = float(p.get("beta_min") or 0), float(p.get("beta_max") or 0)
    if p.get("use_beta") and (bmin or bmax):
        alerts = [a for a in alerts if a.get("beta") is not None and (not bmin or a["beta"] >= bmin) and (not bmax or a["beta"] <= bmax)]
    filtered = len(alerts) != len(all_alerts)
    bench = {}
    for b, _ in BENCHES:
        if b in ds["bars"]:
            bb = ds["bars"][b]
            pos = {d: k for k, d in enumerate(bb["d"].tolist())}
            bench[b] = np.array([bb["c"][pos[d]] if d in pos else np.nan for d in cal.tolist()], dtype="float64")
    hold = int(p.get("hold_days", 252))
    slots = int(p.get("slots", 10))
    start_i, n = info["start_index"], len(cal)

    # horizons without a stop
    hz = {}
    for hd in HORIZONS:
        rets, ex = [], {b: [] for b in bench}
        for a in alerts:
            k = a["i"] + hd
            if k >= n or np.isnan(fr["c"][k, a["j"]]):
                continue
            r = (fr["c"][k, a["j"]] / a["entry"] - 1) * 100
            rets.append(r)
            for b in bench:
                br = _bench_ret(bench[b], a["i"], k)
                if br is not None:
                    ex[b].append(r - br)
        hz[str(hd)] = {"n": len(rets), "win": _r(100 * np.mean([r > 0 for r in rets]), 1) if rets else None,
                       "avg": _r(np.mean(rets)) if rets else None, "median": _r(np.median(rets)) if rets else None,
                       **{f"vs_{b}": _r(np.mean(v)) if v else None for b, v in ex.items()},
                       **{f"beat_{b}": _r(100 * np.mean([x > 0 for x in v]), 1) if v else None for b, v in ex.items()}}

    # stop-loss finder
    st.update(stage="Testing stop losses", total=len(STOP_GRID), done=0)
    finder, main = [], None
    chosen = p.get("stop") or {"type": "none"}
    tp = p.get("take_profit") or {"type": "none"}
    tp = next((x for x in TP_GRID if x["type"] == tp.get("type") and float(x.get("value", 0) or 0) == float(tp.get("value", 0) or 0)), tp)
    for k, stop in enumerate(STOP_GRID):
        st.update(done=k, current=stop["label"])
        trades = run_trades(alerts, fr, bench, stop, hold, tp)
        ts = trade_stats(trades)
        pf = portfolio(trades, fr, start_i, n, slots, skip=skip)
        finder.append({"stop": stop, "stats": ts, "portfolio": {kk: v for kk, v in pf.items() if kk not in ("equity", "equity_days")}})
        if stop["type"] == chosen.get("type") and float(stop.get("value", 0) or 0) == float(chosen.get("value", 0) or 0):
            main = (stop, trades, pf)
    if main is None:
        trades = run_trades(alerts, fr, bench, chosen, hold, tp)
        main = (chosen, trades, portfolio(trades, fr, start_i, n, slots, skip=skip))
    # take-profit finder: the chosen stop with each target
    st.update(stage="Testing take profits", total=len(TP_GRID), done=0)
    tp_finder = []
    for k, t in enumerate(TP_GRID):
        st.update(done=k, current=t["label"])
        tt = run_trades(alerts, fr, bench, main[0], hold, t)
        pf_t = portfolio(tt, fr, start_i, n, slots, skip=skip)
        tp_finder.append({"tp": t, "stats": trade_stats(tt), "portfolio": {kk: v for kk, v in pf_t.items() if kk not in ("equity", "equity_days")}})
    tp_risk = sorted((f for f in tp_finder if f["portfolio"].get("calmar") is not None), key=lambda f: -f["portfolio"]["calmar"])
    tp_cagr = sorted((f for f in tp_finder if f["portfolio"].get("cagr") is not None), key=lambda f: -f["portfolio"]["cagr"])
    ranked_ret = sorted((f for f in finder if f["stats"].get("n")), key=lambda f: -(f["stats"]["avg"] or -1e9))
    ranked_risk = sorted((f for f in finder if f["portfolio"].get("calmar") is not None),
                         key=lambda f: -f["portfolio"]["calmar"])
    ranked_cagr = sorted((f for f in finder if f["portfolio"].get("cagr") is not None),
                         key=lambda f: -f["portfolio"]["cagr"])

    stop, trades, pf = main
    # equity curves, weekly samples to keep the page light
    step = 5
    idxs = list(range(0, len(pf["equity"]), step))
    if pf["equity"] and idxs[-1] != len(pf["equity"]) - 1:
        idxs.append(len(pf["equity"]) - 1)
    days_main = pf.get("equity_days") or list(range(start_i, start_i + len(pf["equity"])))

    daily = {}       # name -> {day index: value}, for the per-year charts

    def at(res, name=None):
        """A result's curve sampled on the strategy's days (left-out years removed)."""
        eq = res["equity"]
        if name:
            daily[name] = dict(zip(res.get("equity_days") or range(start_i, start_i + len(eq)), eq))
        if res.get("equity_days") is None:
            return [_r(eq[x], 0) if x < len(eq) else None for x in idxs]
        m = dict(zip(res["equity_days"], eq))
        return [_r(m.get(days_main[x]), 0) for x in idxs]
    curves = {"t": [str(cal[days_main[x]]) for x in idxs], "Strategy": at(pf, "Strategy")}
    if skip is not None:
        curves["gaps"] = sorted(excl)
    benches = {}
    for b, name in BENCHES:
        if b in bench:
            bh = buy_hold(bench[b], start_i, skip=skip)
            if bh:
                benches[b] = {kk: v for kk, v in bh.items() if kk not in ("equity", "equity_days")}
                benches[b]["name"] = name
                curves[b] = at(bh)
                daily[b] = {d_: float(bench[b][d_]) for d_ in range(start_i, n) if not np.isnan(bench[b][d_])}

    # sector rotation: how alerts did by their sector's quadrant on the alert day, and the filter vs no filter
    sector = None
    if sec_ok:
        trades_all = trades if not filtered else run_trades(all_alerts, fr, bench, stop, hold, tp)
        def group_row(name, grp):
            y1 = [(fr["c"][t["a"]["i"] + 252, t["a"]["j"]] / t["a"]["entry"] - 1) * 100 for t in grp
                  if t["a"]["i"] + 252 < n and not np.isnan(fr["c"][t["a"]["i"] + 252, t["a"]["j"]])]
            return {"quadrant": name, "alerts": len(grp), "y1_avg": _r(np.mean(y1)) if y1 else None,
                    "y1_win": _r(100 * np.mean([x > 0 for x in y1]), 1) if y1 else None, **trade_stats(grp)}
        by_q = [group_row(q or "Unknown", g) for q in QUADRANTS + (None,)
                if (g := [t for t in trades_all if t["a"].get("sq") == q])]
        by_v = [group_row(name, g) for name in ("Undervalued", "Fair value", "Overvalued", None)
                if (g := [t for t in trades_all if sf.val_label(t["a"].get("sv")) == name])]
        for r_ in by_v:
            r_["quadrant"] = r_["quadrant"] or "Unknown"
        sector = {"filter": sec_key, "label": sf.label(sec_key), "kind": sf.kind(sec_key),
                  "by_quadrant": by_q, "by_value": by_v,
                  "alerts_all": len(all_alerts), "alerts_kept": len(alerts)}
        if sec_key != "off":
            pf_all = portfolio(trades_all, fr, start_i, n, slots, skip=skip)
            sector["unfiltered"] = {"stats": trade_stats(trades_all),
                                    "portfolio": {kk: v for kk, v in pf_all.items() if kk not in ("equity", "equity_days")}}
            curves["All sectors"] = at(pf_all, "All sectors")

    _pf_nofilter = None
    # support / macro / theme: which ones predicted a hold, on EVERY alert (filters or not)
    support_tbl = None
    if has_sup or any(a.get("macro") is not None for a in all_alerts[:50]):
        from . import macro as macro_mod, support as sup_mod
        trades_every = trades_all if sec_ok else (trades if not filtered else run_trades(all_alerts, fr, bench, stop, hold, tp))
        rows_ = []
        for t in trades_every:
            a = t["a"]
            line = fr["S"][:, a["j"]] if a["line"] in ("slow", "both") else fr["F"][:, a["j"]]
            held = sup_mod._held(fr["c"][:, a["j"]], line, a["i"], "above", sup_mod.DEFAULTS)
            k = a["i"] + 252
            sig = dict(a.get("sig") or {})
            if a.get("no_repeat") is not None:
                sig["no_repeat"] = a["no_repeat"]
            rows_.append({"signals": sig, "held": held, "ret": t["ret"], "a": a,
                          "r252": (fr["c"][k, a["j"]] / a["entry"] - 1) * 100 if k < n and not np.isnan(fr["c"][k, a["j"]]) else None})
        sup_mod.LABEL.setdefault("no_repeat", "Line hadn't just failed")
        table = sup_mod.compare(rows_, [k for k, _, _ in sup_mod.HIST] + ["no_repeat"]) if has_sup else []

        def grp(name, sel):
            g = [r_ for r_ in rows_ if sel(r_["a"])]
            if not g:
                return None
            held = [r_["held"] for r_ in g if r_["held"] is not None]
            rets = [r_["ret"] for r_ in g]
            y1 = [r_["r252"] for r_ in g if r_["r252"] is not None]
            return {"name": name, "n": len(g), "held_rate": _r(100 * np.mean(held), 1) if held else None,
                    "avg": _r(np.mean(rets)), "win": _r(100 * np.mean([x > 0 for x in rets]), 1),
                    "y1_avg": _r(np.mean(y1)) if y1 else None}
        by_macro = [x for x in (grp("Risk-on (+3 or more)", lambda a: a.get("macro") is not None and a["macro"] >= macro_mod.RISK_ON),
                                grp("Mixed (−2 to +3)", lambda a: a.get("macro") is not None and macro_mod.RISK_OFF <= a["macro"] < macro_mod.RISK_ON),
                                grp("Risk-off (below −2)", lambda a: a.get("macro") is not None and a["macro"] < macro_mod.RISK_OFF)) if x]
        by_theme = [x for x in (grp(f"{k_} warning{'s' if k_ != 1 else ''}", lambda a, k_=k_: a.get("theme_risk") == k_) for k_ in (0, 1, 2, 3)) if x]
        support_tbl = {"signals": table, "by_macro": by_macro, "by_theme": by_theme, "require": require,
                       "macro_min": p.get("macro_min"), "theme_max_risk": p.get("theme_max_risk"),
                       "alerts_all": len(all_alerts), "alerts_kept": len(alerts)}
        if filtered:
            pf_e = portfolio(trades_every, fr, start_i, n, slots, skip=skip)
            support_tbl["unfiltered"] = {"stats": trade_stats(trades_every), "portfolio": {kk: v for kk, v in pf_e.items() if kk not in ("equity", "equity_days")}}
            if "All sectors" not in curves:
                curves["No filters"] = at(pf_e, "No filters")
            _pf_nofilter = pf_e

    # debt buckets: how alerts did by debt level on the alert day (every alert, filters or not)
    debt_tbl = None
    if any(a.get("debt_mcap") is not None for a in all_alerts[:200]):
        trades_d = trades if not filtered else run_trades(all_alerts, fr, bench, stop, hold, tp)

        def bucket(name, sel):
            g = [t for t in trades_d if sel(t["a"])]
            return {"name": name, "n": len(g), **trade_stats(g)} if g else None
        debt_tbl = {"mcap": [x for x in (
            bucket("No debt reported", lambda a: a.get("debt_mcap") is None),
            bucket("Under 10% of market cap", lambda a: a.get("debt_mcap") is not None and a["debt_mcap"] < 10),
            bucket("10–30%", lambda a: a.get("debt_mcap") is not None and 10 <= a["debt_mcap"] < 30),
            bucket("30–60%", lambda a: a.get("debt_mcap") is not None and 30 <= a["debt_mcap"] < 60),
            bucket("60% or more", lambda a: a.get("debt_mcap") is not None and a["debt_mcap"] >= 60)) if x],
            "rev": [x for x in (
            bucket("Under 50% of revenue", lambda a: a.get("debt_rev") is not None and a["debt_rev"] < 50),
            bucket("50–100%", lambda a: a.get("debt_rev") is not None and 50 <= a["debt_rev"] < 100),
            bucket("100–200%", lambda a: a.get("debt_rev") is not None and 100 <= a["debt_rev"] < 200),
            bucket("200% or more", lambda a: a.get("debt_rev") is not None and a["debt_rev"] >= 200)) if x],
            "de": [x for x in (
            bucket("Under 0.5×", lambda a: a.get("debt_de") is not None and a["debt_de"] < 0.5),
            bucket("0.5–1×", lambda a: a.get("debt_de") is not None and 0.5 <= a["debt_de"] < 1),
            bucket("1–2×", lambda a: a.get("debt_de") is not None and 1 <= a["debt_de"] < 2),
            bucket("2× or more", lambda a: a.get("debt_de") is not None and a["debt_de"] >= 2)) if x]}

    # beta: stock beta on the alert day (buckets, every alert) + the strategy's own beta vs SPY
    from . import beta as beta_
    beta_tbl = None
    if any(a.get("beta") is not None for a in all_alerts[:300]):
        trades_b = trades if not filtered else run_trades(all_alerts, fr, bench, stop, hold, tp)
        bk = []
        for name, _, _ in beta_.BUCKETS:
            g = [t for t in trades_b if beta_.bucket(t["a"].get("beta")) == name]
            if g:
                bk.append({"name": name, "n": len(g), **trade_stats(g)})
        beta_tbl = {"buckets": bk}
        bs = [t["a"]["beta"] for t in trades if t["a"].get("beta") is not None]
        beta_tbl["avg_alert_beta"] = _r(float(np.mean(bs)), 2) if bs else None
        beta_tbl["median_alert_beta"] = _r(float(np.median(bs)), 2) if bs else None

    def strat_beta(res):
        """Beta / correlation / alpha of an equity curve vs SPY, on the curve's own days."""
        if "SPY" not in bench or not res or not res.get("equity"):
            return None
        eq = res["equity"]
        dd = res.get("equity_days") or list(range(start_i, start_i + len(eq)))
        spy = bench["SPY"]
        rs = [eq[k] / eq[k - 1] - 1 if eq[k - 1] else np.nan for k in range(1, len(eq))]
        rm = [spy[dd[k]] / spy[dd[k] - 1] - 1 if dd[k] >= 1 and spy[dd[k] - 1] else np.nan for k in range(1, len(eq))]
        return beta_.from_returns(rs, rm)

    def price_beta(series):
        dd = days_main[1:]
        rs = [series[d] / series[d - 1] - 1 if d >= 1 and series[d - 1] else np.nan for d in dd]
        rm = [bench["SPY"][d] / bench["SPY"][d - 1] - 1 if d >= 1 and bench["SPY"][d - 1] else np.nan for d in dd]
        return beta_.from_returns(rs, rm)
    port_beta = {"Strategy": strat_beta(pf)}
    if "SPY" in bench:
        port_beta["SPY"] = {"beta": 1.0, "corr": 1.0, "alpha": 0.0}
        for b in ("QQQ", "RSP"):
            if b in bench:
                port_beta[b] = price_beta(bench[b])
    if _pf_nofilter is not None:
        port_beta["No filters"] = strat_beta(_pf_nofilter)
    if beta_tbl is None:
        beta_tbl = {"buckets": []}
    beta_tbl["portfolio"] = port_beta

    # extension: how far the fast line was above the slow line on the alert day (every alert, filters or not)
    ext_tbl = None
    if any(a.get("ext_spread") is not None for a in all_alerts[:300]):
        trades_x = trades if not filtered else run_trades(all_alerts, fr, bench, stop, hold, tp)

        def xb(name, key, lo, hi):
            g = [t for t in trades_x if t["a"].get(key) is not None and (lo is None or t["a"][key] >= lo) and (hi is None or t["a"][key] < hi)]
            return {"name": name, "n": len(g), **trade_stats(g)} if g else None
        ext_tbl = {"spread": [x for x in (xb("Under 3%", "ext_spread", None, 3), xb("3–6%", "ext_spread", 3, 6), xb("6–10%", "ext_spread", 6, 10),
                                          xb("10–15%", "ext_spread", 10, 15), xb("15–25%", "ext_spread", 15, 25), xb("25% or more", "ext_spread", 25, None)) if x],
                   "peak": [x for x in (xb("Under 10%", "ext_peak", None, 10), xb("10–20%", "ext_peak", 10, 20), xb("20–35%", "ext_peak", 20, 35),
                                        xb("35–50%", "ext_peak", 35, 50), xb("50% or more", "ext_peak", 50, None)) if x],
                   "days": int(p.get("ext_days") or 60)}
        for t in trades_x:
            a_ = t["a"]
            a_["ext_spread_b"] = None if a_.get("ext_spread") is None or a_.get("beta") is None else a_["ext_spread"] * beta_factor(a_["beta"])
        ext_tbl["spread_beta"] = [x for x in (xb("Under 3", "ext_spread_b", None, 3), xb("3–6", "ext_spread_b", 3, 6), xb("6–10", "ext_spread_b", 6, 10),
                                              xb("10–15", "ext_spread_b", 10, 15), xb("15–25", "ext_spread_b", 15, 25), xb("25 or more", "ext_spread_b", 25, None)) if x]

    # earnings: how alerts did by trading days to the next report (every alert, filters or not)
    earn_tbl = None
    if has_earnings(ds) and any(a.get("earn_next") is not None for a in all_alerts):
        trades_e = trades if not filtered else run_trades(all_alerts, fr, bench, stop, hold, tp)

        def eb(name, sel):
            g = [t for t in trades_e if sel(t["a"])]
            return {"name": name, "n": len(g), **trade_stats(g)} if g else None
        nx = lambda a: a.get("earn_next")
        ls_ = lambda a: a.get("earn_last")
        earn_tbl = {"next": [x for x in (
            eb("Report in 1–5 days", lambda a: nx(a) is not None and nx(a) <= 5), eb("6–10 days", lambda a: nx(a) is not None and 6 <= nx(a) <= 10),
            eb("11–20 days", lambda a: nx(a) is not None and 11 <= nx(a) <= 20), eb("21–40 days", lambda a: nx(a) is not None and 21 <= nx(a) <= 40),
            eb("More than 40 days", lambda a: nx(a) is not None and nx(a) > 40), eb("No date known", lambda a: nx(a) is None)) if x],
            "last": [x for x in (
            eb("Reported 0–5 days ago", lambda a: ls_(a) is not None and ls_(a) <= 5), eb("6–10 days ago", lambda a: ls_(a) is not None and 6 <= ls_(a) <= 10),
            eb("11–30 days ago", lambda a: ls_(a) is not None and 11 <= ls_(a) <= 30), eb("More than 30 days ago", lambda a: ls_(a) is not None and ls_(a) > 30)) if x],
            "built": ds.get("earnings_built")}

    # entry quality: pullback speed, weakness vs SPY, touch number, slow-line slope (every alert, filters or not)
    trades_base = trades if not filtered else run_trades(all_alerts, fr, bench, stop, hold, tp)

    def qb(key, edges, fmt_):
        rows_ = []
        for lo, hi in zip([None] + edges, edges + [None]):
            g = [t for t in trades_base if t["a"].get(key) is not None and (lo is None or t["a"][key] >= lo) and (hi is None or t["a"][key] < hi)]
            if g:
                rows_.append({"name": fmt_(lo, hi), "n": len(g), **trade_stats(g)})
        return rows_
    rng = lambda u: (lambda lo, hi: f"under {hi:g}{u}" if lo is None else (f"{lo:g}{u} or more" if hi is None else f"{lo:g} to {hi:g}{u}"))
    quality = {
        "drop": qb("pb_drop", [-15, -10, -6, -3], lambda lo, hi: ("fell more than 15%" if lo is None else ("fell under 3%" if hi is None else f"fell {-hi:g}–{-lo:g}%"))),
        "rel": qb("rel_spy", [-10, -5, 0, 5], lambda lo, hi: ("10+ pts weaker than SPY" if lo is None else ("5+ pts stronger" if hi is None else (f"{-hi:g}–{-lo:g} pts weaker" if hi <= 0 else f"0–{hi:g} pts stronger")))),
        "touch": [dict(r_, name=r_["name"]) for r_ in qb("touch_n", [2, 3, 4], lambda lo, hi: ("1st touch" if lo is None else ("4th touch or later" if hi is None else f"{'2nd' if lo == 2 else '3rd'} touch")))],
        "slope": qb("slow_slope", [0, 2, 5, 10], rng("%")),
        "days": {"speed": int(p.get("speed_days") or 5), "rel": int(p.get("rel_days") or 20), "slope": int(p.get("slope_days") or 60)},
    }

    # which filters help? each filter alone (at its current numbers) vs taking every alert
    report = filter_report(trades_base, p, cal, has_earnings(ds))

    # shares vs calls (modeled with Black-Scholes, see engine/options.py)
    options_res = None
    if p.get("options_compare", True) and trades:
        from . import options as opt
        oc = dict(opt.DEFAULTS, **(p.get("options") or {}))
        st.update(stage="Pricing calls for every alert")
        ivm = opt.iv_matrix(fr["c"], float(oc["iv_mult"]))
        rows_o = opt.grid(trades, fr, ivm, start_i, n, slots, functools.partial(portfolio, skip=skip), trade_stats, float(oc["spread_pct"]), st)
        ot = opt.option_trades(trades, fr, ivm, int(oc["dte"]), float(oc["delta"]), float(oc["spread_pct"]))
        pf_o = portfolio(ot, fr, start_i, n, slots, valuer=opt.option_valuer(fr, ivm), skip=skip)
        curves["Calls"] = at(pf_o, "Calls")
        port_beta["Calls"] = strat_beta(pf_o)
        by_i = {(t["a"]["i"], t["a"]["j"]): t for t in ot}
        for t in trades:
            o = by_i.get((t["a"]["i"], t["a"]["j"]))
            t["opt_ret"] = o["ret"] if o else None
        o_risk = sorted((x for x in rows_o if x["portfolio"].get("calmar") is not None), key=lambda x: -x["portfolio"]["calmar"])
        o_cagr = sorted((x for x in rows_o if x["portfolio"].get("cagr") is not None), key=lambda x: -x["portfolio"]["cagr"])
        options_res = {"settings": oc, "grid": rows_o, "stats": trade_stats(ot),
                       "portfolio": {kk: v for kk, v in pf_o.items() if kk not in ("equity", "equity_days")},
                       "best": {"risk": o_risk[0] if o_risk else None, "cagr": o_cagr[0] if o_cagr else None},
                       "avg_iv": _r(np.mean([t["opt"]["iv"] for t in ot]) * 100, 0) if ot else None,
                       "avg_cost_pct": _r(np.mean([t["opt"]["prem"] / t["a"]["entry"] * 100 for t in ot]), 1) if ot else None,
                       "expired": _r(100 * sum(1 for t in ot if t["reason"] == "expired") / len(ot), 1) if ot else None}
        verdict_rows = [("Shares", pf.get("cagr"), pf.get("calmar"))] + [(x["label"], x["portfolio"].get("cagr"), x["portfolio"].get("calmar")) for x in rows_o]
        best_cagr = max((v for v in verdict_rows if v[1] is not None), key=lambda v: v[1], default=None)
        best_risk = max((v for v in verdict_rows if v[2] is not None), key=lambda v: v[2], default=None)
        options_res["winner"] = {"cagr": best_cagr[0] if best_cagr else None, "risk": best_risk[0] if best_risk else None}

    # by year
    years = {}
    for t in trades:
        y = str(cal[t["a"]["i"]])[:4]
        years.setdefault(y, []).append(t)
    by_year = [{"year": y, **trade_stats(v)} for y, v in sorted(years.items())]
    by_line = {ln: trade_stats([t for t in trades if t["a"]["line"] == ln]) for ln in ("fast", "slow", "both")}

    # alert list grouped by day (newest first)
    days = {}
    flat = []
    for t in trades:
        a = t["a"]
        k = a["i"]
        flat.append({"date": str(cal[k]), "ticker": a["ticker"], "line": a["line"], "entry": _r(a["entry"]), "exit": _r(t["exit"]),
                     "exit_date": str(cal[t["exit_i"]]), "days": t["days"], "reason": t["reason"], "sector": a.get("sector"),
                     "ret": _r(t["ret"]), "spy": _r(t["bench"].get("SPY")), "qqq": _r(t["bench"].get("QQQ")),
                     "vs_SPY": _r(t["ret"] - t["bench"]["SPY"]) if t["bench"].get("SPY") is not None else None,
                     "vs_QQQ": _r(t["ret"] - t["bench"]["QQQ"]) if t["bench"].get("QQQ") is not None else None,
                     "opt_ret": _r(t.get("opt_ret"))})
        row = {"ticker": a["ticker"], "line": a["line"], "entry": _r(a["entry"]), "mcap_b": a["mcap"],
               "sq": a.get("sq"), "sv": _r(a.get("sv"), 1), "sector": a.get("sector"),
               "debt_mcap": a.get("debt_mcap"), "debt_rev": a.get("debt_rev"), "debt_de": a.get("debt_de"),
               "sig": a.get("sig"), "macro": _r(a.get("macro"), 1), "beta": a.get("beta"), "ext_spread": a.get("ext_spread"), "ext_peak": a.get("ext_peak"), "earn_next": a.get("earn_next"), "earn_last": a.get("earn_last"),
               "pb_drop": a.get("pb_drop"), "rel_spy": a.get("rel_spy"), "touch_n": a.get("touch_n"), "slow_slope": a.get("slow_slope"), "theme": a.get("theme"), "theme_risk": a.get("theme_risk"),
               "ret": _r(t["ret"]), "days": t["days"], "opt_ret": _r(t.get("opt_ret")), "reason": t["reason"], "exit_date": str(cal[t["exit_i"]]),
               "vs_SPY": _r(t["ret"] - t["bench"]["SPY"]) if t["bench"].get("SPY") is not None else None}
        for hd in (21, 63, 252):
            kk = k + hd
            row[f"r{hd}"] = _r((fr["c"][kk, a["j"]] / a["entry"] - 1) * 100) if kk < n and not np.isnan(fr["c"][kk, a["j"]]) else None
        days.setdefault(str(cal[k]), []).append(row)
    alert_days = [{"date": d, "alerts": v} for d, v in sorted(days.items(), reverse=True)]
    extremes = winners_losers(flat)

    yearly = year_curves(days_main, cal, daily, skip)
    for y_, yv in yearly.items():
        bt_ = next((b_ for b_ in by_year if b_["year"] == y_), None)
        if bt_:
            yv["trades"] = {k_: bt_.get(k_) for k_ in ("n", "open", "win", "avg", "vs_SPY")}

    return {
        "yearly": yearly,
        "params": p, "info": info, "universe": len(tickers), "alerts_total": len(alerts),
        "alert_days": alert_days[:400], "alert_days_total": len(alert_days), "_all_days": alert_days,
        "horizons": hz, "stop": stop, "take_profit": tp, "stats": trade_stats(trades), "tp_finder": tp_finder,
        "tp_best": {"risk": tp_risk[0]["tp"] if tp_risk else None, "cagr": tp_cagr[0]["tp"] if tp_cagr else None},
        "portfolio": {kk: v for kk, v in pf.items() if kk not in ("equity", "equity_days")}, "benchmarks": benches, "curves": curves,
        "by_year": by_year, "by_line": by_line, "extremes": extremes, "finder": finder, "sector": sector, "support": support_tbl, "options": options_res, "debt": debt_tbl, "beta": beta_tbl, "extension": ext_tbl, "earnings": earn_tbl, "quality": quality, "filter_report": report,
        "best": {"return": ranked_ret[0]["stop"] if ranked_ret else None,
                 "risk": ranked_risk[0]["stop"] if ranked_risk else None,
                 "cagr": ranked_cagr[0]["stop"] if ranked_cagr else None},
        "dataset_built": ds["built"], "fails": ds.get("fails", [])[:10],
        "finished": datetime.now().isoformat(timespec="seconds"),
    }
